import os, sys, time
import importlib
import torch
import numpy as np
from torch.utils.tensorboard import SummaryWriter

from model import RecurrentTransFormer as MODEL
from model import AgentModel
# from model import MLPModel as AgentModel

# from model import ModeModel as AgentModel
# from social_vae import SocialVAE
# from data_svae import Dataloader
import torch.nn as nn
from data import Dataloader
from SocialVAE.utils import FPC, seed, get_rng_state, set_rng_state, vis

from util import ADE_FDE
import ipdb
import argparse
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
import tqdm

parser = argparse.ArgumentParser()
parser.add_argument("--train", nargs='+', default=[])
parser.add_argument("--test", nargs='+', default=[])
parser.add_argument("--frameskip", type=int, default=1)
parser.add_argument("--config", type=str, default=None)
parser.add_argument("--ckpt", type=str, default=None)
parser.add_argument("--device", type=str, default='0')
parser.add_argument("--dataset", type=str, default='hotel')
parser.add_argument("--seed", type=int, default=1)
parser.add_argument("--no-fpc", action="store_true", default=False)
parser.add_argument("--fpc-finetune", action="store_true", default=False)
parser.add_argument("--retrain", type=bool, default=False)
parser.add_argument("--vis", type=bool, default=False)
parser.add_argument("--pixel", type=bool, default=False)
parser.add_argument("--edtion", type=str, default='0')
parser.add_argument("--lamb", type=float, default=0.1)
parser.add_argument("--inference", type=bool, default=False)

# python main.py --train /data2/wuqi/project/SocialVAE/data/sdd/train --test /data2/wuqi/project/SocialVAE/data/sdd/test   --dataset sdd --pixel True  --edtion momd --device 3  --lamb 0.1 --retrain True

# python main.py --train /data2/wuqi/project/SocialVAE/data/sdd/train --test /data2/wuqi/project/SocialVAE/data/sdd/test   --dataset eth  --edtion 0 --device 6  --lamb 0.1 --retrain True

# python main.py --train /data2/wuqi/project/SocialVAE/data/sdd/train --test /data2/wuqi/project/SocialVAE/data/sdd/test   --dataset score  --edtion MoP --device 0  --lamb 0.1 --retrain True

def train(model,dataset,epoch,optimizer=None,static_modes=None):
    print('+++++ train +++++')
    modality_labels = None
    model.train()
   
    losses = {}
    for batch_idx, item in enumerate(dataset):
        x,y,neighbor = item[0], item[1],item[2]
        
        model_out = model(agent=x,modality_labels=modality_labels,neighbor=neighbor)
        pred_traj = model_out[0]
        pred_prob = model_out[1]
        score = None
        
        loss = model.get_loss(pred_traj,y,modality_labels,static_modes=static_modes)
        # if epoch >1:
        loss = model.get_prob_loss(loss, pred_traj, y, score,pred_prob,modality_labels=modality_labels)
        loss["total"].backward()
        optimizer.step()
        optimizer.zero_grad()
        for k, v in loss.items():
            if k not in losses: 
                losses[k] = v.item()
            else:
                losses[k] = (losses[k]*batch_idx+v.item())/(batch_idx+1)
        sys.stdout.write("\r" )
        sys.stdout.write("{}/{}| ".format(batch_idx+1, len(dataset)) )
        for k, v in losses.items():
            sys.stdout.write("{}: {:.3f}| ".format(k, v) )
        sys.stdout.flush()
    sys.stdout.write("\r" )
    sys.stdout.flush()
    return losses

def test(model,e2e_model,dataset,modality_labels=None):
    print('\n+++++ test  +++++')
    model.eval()
    e2e_model.eval()
    e2e_model = None
    ADE, FDE,BADE, BFDE = [], [], [], []
    batch = 0
    
    AGENT,GT,PRED,PROB = [], [], [], []
    
    time_cost = 0
    dataset_len = 0
    batch_count = 0
    with torch.no_grad():
        for agent, gt, neighbor in dataset:
            batch_count+=1
            batch += agent.size(0)
            
            ### create moal labels
            # if e2e_model is not None:
            #     modality_labels = e2e_model(agent[...,:2])
            # else:
            #     print('+'*20)
            #     print('no modality labels!!!')
            #     modality_label = torch.randn_like(gt)
            #     modality_labels =modality_label[:,None,:,:].repeat(1,20,1,1)
            tic = time.perf_counter()
            model_out = model(agent=agent,modality_labels=modality_labels,neighbor=neighbor)
            toc = time.perf_counter()
            time_cost += toc-tic
            pred_traj = model_out[0]
            pred_prob = model_out[1] # B, 20
            
            ade, fde = ADE_FDE(pred_traj, gt) # B, pred_num
            batch_ade, batch_fde = ade, fde
            ade = torch.min(ade, dim=1)[0]
            fde = torch.min(fde, dim=1)[0]
            
            ### append list
            ADE.append(ade)
            FDE.append(fde)
            BADE.append(batch_ade)
            BFDE.append(batch_fde)
            ### model outs
            AGENT.append(agent[...,:2])
            GT.append(gt)
            PRED.append(pred_traj)
            PROB.append(pred_prob)
            
            
        ADE = torch.cat(ADE)
        FDE = torch.cat(FDE)
        
        BADE = torch.cat(BADE,dim=0)
        BFDE = torch.cat(BFDE,dim=0)
        PROB = torch.cat(PROB,dim=0)
        # PROB = None
        if False:
        # if True:
            AGENT = torch.cat(AGENT,dim=0)
            GT = torch.cat(GT,dim=0)
            
            PRED = torch.cat(PRED,dim=0)
            save_path = '/data2/wuqi/project/fig/eth/'
            vis(obs_trajs=AGENT, queries=None, gt_trajs=GT, y_tests =None,y_linear=None,y_kf =None, pred_trajs=PRED, global_fig=False, save_path=save_path,probs=None)
            
            
            
            
        ### rescale metrics
        if torch.is_tensor(config.WORLD_SCALE) or config.WORLD_SCALE != 1:
            if not torch.is_tensor(config.WORLD_SCALE):
                config.WORLD_SCALE = torch.as_tensor(config.WORLD_SCALE, device=ADE.device, dtype=ADE.dtype)
            
            ADE *= config.WORLD_SCALE
            FDE *= config.WORLD_SCALE
            
            BADE *= config.WORLD_SCALE[:,None]
            BFDE *= config.WORLD_SCALE[:,None]
            
        ### brief ADE/FDE
        BADE = BADE + (1-PROB)**2
        BFDE = BFDE + (1-PROB)**2
        BADE = torch.min(BADE, dim=1)[0]
        BFDE = torch.min(BFDE, dim=1)[0]
        
        ### eval in whole dataset
        ade = ADE.mean()
        fde = FDE.mean()
        bade = BADE.mean()
        bfde = BFDE.mean()
        toc = time.time()
        print("  ADE/  FDE:{:.2f}/{:.2f}\nB-ADE/B-FDE:{:.2f}/{:.2f}".format(ade, fde, bade, bfde))
        print("time:{:.5f}".format(100*(time_cost/batch)))

    return ade, fde, bade, bfde


if __name__ == "__main__":
    
    
    settings = parser.parse_args()
    settings.train[0] = '/data2/wuqi/project/SocialVAE/data/' + settings.dataset +'/train'
    settings.test[0] = '/data2/wuqi/project/SocialVAE/data/' + settings.dataset +'/test'
    if settings.dataset in ['rebound', 'score']:
        settings.train[0] = '/data2/wuqi/project/SocialVAE/data/nba/' + settings.dataset +'/train'
        settings.test[0] = '/data2/wuqi/project/SocialVAE/data/nba/' + settings.dataset +'/test'
    # settings.config =  'SocialVAE/config/' + settings.dataset + '.py'
    if settings.dataset in ['eth', 'hotel', 'univ', 'zara01', 'zara02']:
        settings.config =  'config.py'
    elif settings.dataset in ['rebound', 'score']:
        settings.config =  'SocialVAE/config/' + 'nba_' +settings.dataset+ '.py'
    else:
        settings.config =  'SocialVAE/config/' + 'sdd_pixel' + '.py'
    edtion = settings.edtion
    settings.ckpt = 'ckpt/' + settings.dataset+'_' +settings.edtion
    
    os.makedirs(settings.ckpt,exist_ok=True)
    
    spec = importlib.util.spec_from_file_location("config", settings.config)
    config = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(config)
    
    plot_on = settings.vis
    pixel = settings.pixel
    
    ### device
    if settings.device is None:
        settings.device = "cuda" if torch.cuda.is_available() else "cpu"
    settings.device = "cuda:" + settings.device
    settings.device = torch.device(settings.device)
    torch.manual_seed(3407)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    torch.cuda.manual_seed(3407)
    
    ### 
    
    
    
    
    
    
        
        
    
    
    model = AgentModel(
        in_size=2, 
        obs_len=config.OB_HORIZON, 
        pred_len=config.PRED_HORIZON, 
        embed_size=256, 
        num_spa_int_layer=1, 
        heads=4, 
        forward_expansion=2,
        lamb = settings.lamb
        )
    model.to(settings.device)
    
    optimizer = torch.optim.Adam(model.parameters(), lr=config.LEARNING_RATE)
    start_epoch = 0
    
 
    
    ade, fde, bade, bfde = 1e3, 1e3, 1e3, 1e3
    
    repetitions = 10000
    N = 20
    dummy_input = torch.rand(N, 8, 2).to(settings.device)
    #python inference_time.py --train /data2/wuqi/project/SocialVAE/data/sdd/train --test /data2/wuqi/project/SocialVAE/data/sdd/test   --dataset sdd --pixel True  --edtion momd --device 2  --lamb 0.1 
    print('warm up ...\n')
    with torch.no_grad():
        for _ in range(1000):
            model_out = model(agent=dummy_input,modality_labels=None,neighbor=None)
            
    torch.cuda.synchronize()
    starter, ender = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
    timings = np.zeros((repetitions, 1))
    
    
    print('testing ...\n')
    with torch.no_grad():
        for rep in tqdm.tqdm(range(repetitions)):
            starter.record()
            _ = model(dummy_input)
            ender.record()
            torch.cuda.synchronize() # 等待GPU任务完成
            curr_time = starter.elapsed_time(ender) # 从 starter 到 ender 之间用时,单位为毫秒
            timings[rep] = curr_time

    avg = timings.sum()/repetitions
    print('\navg={}\n'.format(avg/1000))
    
    
    exit()
    
    for epoch in range(start_epoch+1, end_epoch+1):
        if settings.inference : break
        if epoch <= config.EPOCHS:
            static_modes = None
           
            
            print('='*40)
            tic = time.time()
            losses = train(model=model,dataset=train_data,static_modes=static_modes, epoch=epoch, optimizer =optimizer)
            toc = time.time()
            
            sys.stdout.write("Epoch {}/{} t cost:{:.2f}|".format(epoch, config.EPOCHS,toc-tic))
            for k, v in losses.items():
                sys.stdout.write("{}: {:.3f}| ".format(k, v) )
            sys.stdout.flush()
        if epoch >= config.TEST_SINCE:
            ade, fde, bade, bfde = test(model,e2e_model=e2e_model, dataset= test_data,modality_labels=cluster_centers)
            # exit()
        state = dict(
            model=model.state_dict(),
            optimizer=optimizer.state_dict(),
            ade=ade, fde=fde, bade=bade,bfde=bfde,
            epoch=epoch
        )
        torch.save(state, ckpt)
        if ade < ade_best:
            ade_best = ade
            fde_best = fde
        if bade < b_ade_best:
            b_ade_best = bade
            b_fde_best = bfde
            best_ep = epoch
            state_best = dict(
                model=state["model"],
                ade=ade, fde=fde, bade=bade,bfde=bfde,
                epoch=epoch
            )
            torch.save(state_best, ckpt_best)
            print('epoch{} best  ade/ fde:{:.3f}/{:.3f}'.format(epoch,ade_best, fde_best))
            print('epoch{} best bade/bfde:{:.3f}/{:.3f}'.format(epoch,b_ade_best, b_fde_best))
    
    state_dict = torch.load(ckpt_best, map_location=settings.device)
    model.load_state_dict(state_dict["model"])
    ade, fde, bade, bfde = test(model,e2e_model=e2e_model, dataset= test_data,modality_labels=cluster_centers)
    ### write into log
    file_path = "eval.txt"
    text_to_append = "{} ed-{} best ep {} best ADE/FDE: {:.2f}/{:.2f}|||best BADE/BFDE: {:.2f}/{:.2f}".format(settings.dataset,settings.edtion,best_ep,ade_best,fde_best,b_ade_best, b_fde_best)
    text_to_append =  text_to_append+'\n'
    
    ### 
    def append_to_file(file_path, text):
        with open(file_path, 'a') as file:
            file.write(text + '\n')
    append_to_file(file_path, text_to_append)
        
    