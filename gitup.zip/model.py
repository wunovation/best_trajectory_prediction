import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import math
import ipdb
import random
import sys
import ipdb
import os
import time
from copy import deepcopy
from sklearn.metrics import accuracy_score
# import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
# from model_utils.RTR_encoder import RTR_Encoder
# from model_utils.RTR_decoder import RTR_Decoder
from model_utils.block_utils import attention
from transformer_dec import Decoder
from transformer_enc import Encoder
# from .model_utils.RTR_encoder import RTR_Encoder


class RecurrentTransFormer(nn.Module):
    
    def __init__(self, in_size, obs_len, pred_len, embed_size=64, num_spa_int_layer=1, heads=4, forward_expansion=2, lamb=0.1):
        super(RecurrentTransFormer, self).__init__()
        self.islinear = False
        self.obs_len = 8
        self.pred_len = 12
        self.pred_num = 20
        self.lamb = lamb
        
        d_dim = 2
        self.embed_dim = embed_size
        
        self.reg_head_in = torch.nn.Sequential(
            torch.nn.Linear(self.embed_dim, self.embed_dim*2),            
            torch.nn.ReLU6(),
            # torch.nn.Linear(self.embed_dim*2, self.pred_len*self.pred_num*d_dim),
        )
        self.reg_head_outs = nn.ModuleList([torch.nn.Linear(self.embed_dim*2, self.pred_len*d_dim) for _ in range(self.pred_num)])
        
        
        self.rnn_enc = RTR_Encoder(embed_size=embed_size, num_layers=num_spa_int_layer, heads=heads, forward_expansion=forward_expansion, islinear=self.islinear)
        
        self.modality_emb = torch.nn.Sequential(
            torch.nn.Linear(self.pred_len*in_size, self.embed_dim*2),            
            torch.nn.ReLU6(),
            torch.nn.Linear(self.embed_dim*2, self.embed_dim),
        )
        
        self.dec = RTR_Decoder(embed_size=embed_size, num_layers=num_spa_int_layer, heads=heads, forward_expansion=forward_expansion, islinear=self.islinear)
        
        
        
        
        self.prob_head = torch.nn.Sequential(
            torch.nn.Linear(self.embed_dim, self.embed_dim*2),            
            torch.nn.ReLU6(),
            torch.nn.Linear(self.embed_dim*2, self.pred_num),
            nn.Softmax(dim=-1)
        ) 
        self.att_score = None
        self.softmax = nn.Softmax(dim=-1)
        self.ce_loss = nn.CrossEntropyLoss()
        # self.BCE = F.binary_cross_entropy(reduction='mean')
        
    
    def forward(self, x,neighbor,modality_labels):
        batch_size = x.size(0)
        memory_out = self.rnn_enc(x,neighbor[:,:self.obs_len])
        
        # inv_rnn_outs = self.rnn_enc.layers[0].modality_embedding(agent=x, neighbor=neighbor, modality_labels=modality_labels)
        
        # inv_rnn_outs = inv_rnn_outs.permute(1,0,2,3).sum(2)# B K pred_len emb -> B K  emb 
        
        # inv_rnn_outs = inv_rnn_outs.reshape(batch_size,-1, self.embed_dim)
        # modality_labels
        modal_k = modality_labels.size(1)
        modality_labels = modality_labels.reshape(batch_size, modal_k, -1)
        modality_emb = self.modality_emb(modality_labels) # B K pred_len 2
        
        
        dec_out,score = self.dec(query = memory_out, key = modality_emb)
        emb = dec_out.squeeze()
        
        # emb = emb.mean(dim=0)
        # emb = emb[None,:].repeat(batch_size,1)
        
        pred_prob = self.prob_head(emb)
        
        pred_trajs = []
        for k in range(self.pred_num):
            reg_emb = self.reg_head_in(emb)
            
            pred_traj = self.reg_head_outs[k](reg_emb).reshape(batch_size,1,12,2)
            pred_trajs.append(pred_traj)
        pred_trajs = torch.cat(pred_trajs, dim=1)
        # pred_trajs = self.reg_head(dec_out).reshape(batch_size, 20, 12, 2)
        pred_trajs = torch.cumsum(pred_trajs, dim=2)
        # endpoint = x[-1,:,None,:2]
        
        # pred_trajs = pred_trajs + endpoint[:,None,:,:]
        
        return pred_trajs, pred_prob, score
    
    def get_loss(self, pred_trajs, gt_trajs):
        # gt_trajs = gt_trajs.permute(1,0,2)
        loss = {'total':0}
        
        err = torch.norm(pred_trajs - gt_trajs.unsqueeze(1), dim=-1)
        batch_ade = err.mean(dim=-1) # batch_size pred_num
        closest_indices = torch.min(batch_ade, dim=-1)[1]
        reg_loss = err[torch.LongTensor(range(closest_indices.shape[0])), closest_indices] # [batch_size]
        loss['variety'] = reg_loss.mean()
        loss['total'] += loss['variety']
        return loss
    
    def get_prob_loss(self,loss, pred_trajs, gt_trajs, score,pred_prob):
        err = torch.norm(pred_trajs - gt_trajs.unsqueeze(1), dim=-1) # [batch_size pred_num pred_len]
        distance = err.mean(dim=-1) # batch_size pred_num
        dist_score = self.softmax(-distance) 
        quantiles = torch.quantile(dist_score, q=0.75, dim=1)
        quantiles = quantiles[:,None].repeat(1,20)
        
        binary_score = dist_score > quantiles
        # max_indices = torch.argmax(dist_score, dim=1)
        label = binary_score.to(torch.float)

        # prob = pred_prob+ score
        # prob = self.softmax(prob)
        
        loss['ce'] = F.binary_cross_entropy(pred_prob, dist_score,reduction='mean')
        loss['total'] += 0.5*loss['ce']
        
        # kl_divergence = F.kl_div(pred_prob.log(), dist_score, reduction='batchmean')
        # loss['kl'] = kl_divergence
        # loss['total'] += loss['kl'] 
        return loss
    
    
        
class AgentModel(nn.Module):
    
    def __init__(self, in_size, obs_len, pred_len, embed_size=64, num_spa_int_layer=1, heads=4, forward_expansion=2,lamb=0.1):
        super(AgentModel, self).__init__()
        
        self.obs_len = obs_len
        self.pred_len = pred_len
        self.pred_num = 20
        self.lamb = lamb

        self.embed_dim = embed_size
        self.islinear = False
        
        self.motion_mode_embedding = nn.Sequential(
            nn.Linear(in_size*(pred_len), embed_size),
            nn.ReLU(),
            nn.Linear(embed_size, embed_size),
        )
        
        self.agent_embedding = nn.Sequential(
            nn.Linear(in_size*(obs_len), embed_size),
            nn.ReLU(),
            nn.Linear(embed_size, embed_size),
        )
        
        self.enc_fc = nn.Linear(2*embed_size, embed_size)
        
        self.prob_head = torch.nn.Sequential(
            torch.nn.Linear(self.embed_dim, self.embed_dim*2),            
            torch.nn.ReLU6(),
            torch.nn.Linear(self.embed_dim*2, self.pred_num),
            nn.Softmax(dim=-1)
        ) 
        self.spa_int_enc = Encoder(embed_size, num_spa_int_layer, heads, forward_expansion, islinear=self.islinear)

        self.spa_att_dec = Decoder(embed_size, num_spa_int_layer, heads, forward_expansion, islinear=self.islinear)
        
        self.dest_embedding = nn.Sequential(
            nn.Linear(2, embed_size),
            nn.ReLU(),
            nn.Linear(embed_size, embed_size)
        )
        
        self.reg_head = nn.Sequential(
            nn.Linear(embed_size, embed_size*2),
            nn.ReLU(),
            nn.Linear(embed_size*2, self.pred_len*2*self.pred_num)
        )
        self.att_score = None
        self.criterion = nn.SmoothL1Loss(reduction='mean')
        self.softmax = nn.Softmax(dim=-1)
        self.ce_loss = nn.CrossEntropyLoss()
        
        self.reg_head_in = torch.nn.Sequential(
            torch.nn.Linear(self.embed_dim, self.embed_dim*2),            
            torch.nn.ReLU6(),
            # torch.nn.Linear(self.embed_dim*2, self.pred_len*self.pred_num*d_dim),
        )
        # self.reg_head_outs = nn.ModuleList([
        #     torch.nn.Sequential(
        #     torch.nn.Linear(self.embed_dim, self.embed_dim*2),            
        #     torch.nn.ReLU6(),
        #     torch.nn.Linear(self.embed_dim*2, self.pred_len*2)
        #     )
        #     for _ in range(self.pred_num)])
        
        self.reg_head_outs = nn.ModuleList([
             torch.nn.Linear(self.embed_dim*2, self.pred_len*2)
            for _ in range(self.pred_num)])
        
        self.query_outs = nn.ModuleList([
            torch.nn.Sequential(
            torch.nn.Linear(self.embed_dim, self.embed_dim*2),            
            torch.nn.ReLU6(),
            )
            for _ in range(self.pred_num)])
        
    def forward(self,agent, neighbor=None, modality_labels=None):
        agent = agent[...,:2]
        batch_size, obs_len, in_size = agent.shape
        if neighbor is not None:
            Nn = neighbor.size(2)
            neighbor = neighbor[:,:obs_len,:, :in_size].permute(0,2,1,3)
            nei = neighbor.reshape(batch_size,Nn,-1)
            neighbor_embedding = self.agent_embedding(nei)
            var_pos = agent.unsqueeze(1) - neighbor
            dist = var_pos.norm(dim=-1).sum(-1) 
            mask = dist < 1e4
        # mode_num = modality_labels.size(0)
        ax = agent.reshape(batch_size,-1)
        
        agent_embedding = self.agent_embedding(ax).unsqueeze(1)

        
        spa_int = self.spa_int_enc(agent_embedding,neighbor_embedding,neighbor_embedding, valid_mask=None, att_mask=mask) # [batch_size embed_size]
        # spa_int = self.spa_int_enc(agent_embedding,agent_embedding,agent_embedding, valid_mask=None, att_mask=None) # [batch_size embed_size]
        
        dec_out = self.spa_att_dec(agent_embedding, spa_int, valid_mask=None, cross_att_mask=None).squeeze()
        # b emb
        emb = dec_out.squeeze()

        PRED = []
        mode_querys = []
        for p in range(self.pred_num):
            mode_query = self.query_outs[p](emb)
            mode_querys.append(mode_query[:,None,:])
        mode_querys = torch.cat(mode_querys, dim=1)
        score, mode_outs = self.self_attention(mode_querys,mode_querys,mode_querys)
        
        for p in range(self.pred_num):
            pred = (self.reg_head_outs[p](mode_outs[:,p])).reshape(batch_size,1,12,2)
            PRED.append(pred)
            
        pred = torch.cat(PRED,dim=1)
        pred_trajs = torch.cumsum(pred, dim=2)
        # pred = self.reg_head(dec_out.reshape(batch_size, -1))
        
        # pred_trajs = pred[:,:self.pred_len*2*self.pred_num].reshape(batch_size, self.pred_num, self.pred_len, 2)
        

        # emb = emb.mean(dim=0)
        # emb = emb[None,:].repeat(batch_size,1)
        pred_prob = self.prob_head(emb)


        
        return pred_trajs, pred_prob
    
    def get_loss(self, pred_trajs, gt_trajs,pred_prob=None, modality_labels=None, static_modes=None):
        '''
        pred_trajs: B, pred_num, pred_len, 2
        gt_trajs: B, pred_len, 2
        '''
        
        loss = {'total':0}
        distance = torch.norm(pred_trajs - gt_trajs.unsqueeze(1), dim=-1).mean(dim=-1) # [batch_size pred_num pred_len]        
      
        closest_indices = torch.min(distance, dim=-1)[1]
        reg_loss = distance[torch.LongTensor(range(closest_indices.shape[0])), closest_indices] # [batch_size]
        closest_pred = pred_trajs[torch.LongTensor(range(closest_indices.shape[0])), closest_indices]
        ind_count = torch.bincount(closest_indices, minlength=20)
        
        loss['variety'] = reg_loss.mean()
        loss['total'] += loss['variety']
        
        return loss, ind_count
    
    def get_prob_loss(self,loss, pred_trajs, gt_trajs, score,pred_prob, modality_labels=None):
        err = torch.norm(pred_trajs - gt_trajs.unsqueeze(1), dim=-1) # [batch_size pred_num pred_len]
        distance = err.mean(dim=-1) # batch_size pred_num 
        dist_score = self.softmax(-distance) 
        loss['ce'] = self.ce_loss(pred_prob, dist_score)
        loss['total'] += self.lamb *loss['ce']
        return loss
    
    def self_attention(self, query,key,value, mask=None, dropout=None):
        # q: Bx emb
        # k: B x Nnum x emb
        # mask: B x Nnum
        attention_nonlinearity = torch.nn.LeakyReLU(0.2)
        
        score = (key @ query.permute(0,2,1)).squeeze(-1)           # N x Nn
        score = attention_nonlinearity(score)              # N x Nn
        if mask is not None:
            score[~mask] = -float("inf")
        score = torch.nn.functional.softmax(score, dim=-1).nan_to_num()    # N x Nn
        
        if dropout is not None:
            score = dropout(score)
            
        logits = score @ value
        return score, logits
   
class ModeModel(nn.Module):
    
    def __init__(self, in_size, obs_len, pred_len, embed_size=64, num_spa_int_layer=1, heads=4, forward_expansion=2,lamb=0.1):
        super(ModeModel, self).__init__()
        
        self.obs_len = obs_len
        self.pred_len = pred_len
        self.pred_num = 20

        self.embed_dim = embed_size
        self.islinear = False
        self.embed_motion = torch.nn.Sequential(
            torch.nn.Linear(4*(obs_len-1), 64),             # v, a
            torch.nn.ReLU6(),
            torch.nn.Linear(64, self.embed_dim),
        )
        self.embed_delta = torch.nn.Sequential(
            torch.nn.Linear(4*(obs_len-1), 64),             # dp, dv
            torch.nn.ReLU6(),
            torch.nn.Linear(64, self.embed_dim),
            torch.nn.ReLU6(),
            torch.nn.Linear(self.embed_dim, self.embed_dim)
        )
        self.embed_feat = torch.nn.Sequential(
            torch.nn.Linear(3*(obs_len-1), self.embed_dim),    # dist, bear angle, mpd
            torch.nn.ReLU6(),
            torch.nn.Linear(self.embed_dim, self.embed_dim),
            torch.nn.ReLU6(),
            torch.nn.Linear(self.embed_dim, self.embed_dim)
        )
        self.embed_q = torch.nn.Sequential(
            torch.nn.Linear(self.embed_dim, self.embed_dim),
            torch.nn.ReLU6(),
            torch.nn.Linear(self.embed_dim, self.embed_dim),
            torch.nn.ReLU6(),
            torch.nn.Linear(self.embed_dim, self.embed_dim)
        )
        
        self.motion_mode_embedding = nn.Sequential(
            nn.Linear(in_size*(pred_len), embed_size),
            nn.ReLU(),
            nn.Linear(embed_size, embed_size),
        )
        
        self.neighbor_embedding = nn.Sequential(
            nn.Linear(in_size*(obs_len), embed_size),
            nn.ReLU(),
            nn.Linear(embed_size, embed_size),
        )
        
        self.agent_embedding = nn.Sequential(
            nn.Linear(in_size*(obs_len+pred_len), embed_size),
            nn.ReLU(),
            nn.Linear(embed_size, embed_size),
        )
        
        self.enc_fc = nn.Linear(2*embed_size, embed_size)
        
        self.prob_head = torch.nn.Sequential(
            torch.nn.Linear(self.embed_dim, self.embed_dim*2),            
            torch.nn.ReLU6(),
            torch.nn.Linear(self.embed_dim*2, self.pred_num),
            nn.Softmax(dim=-1)
        ) 
        self.spa_int_enc = Encoder(embed_size, num_spa_int_layer, heads, forward_expansion, islinear=self.islinear)

        self.spa_att_dec = Decoder(embed_size, num_spa_int_layer, heads, forward_expansion, islinear=self.islinear)
        self.dest_embedding = nn.Sequential(
            nn.Linear(2, embed_size),
            nn.ReLU(),
            nn.Linear(embed_size, embed_size)
        )
        
        self.reg_head = nn.Sequential(
            nn.Linear(embed_size, embed_size*2),
            nn.ReLU(),
            nn.Linear(embed_size*2, self.pred_len*2*self.pred_num)
        )
        self.att_score = None
        self.softmax = nn.Softmax(dim=-1)
        self.ce_loss = nn.CrossEntropyLoss()
        
        self.reg_head_in = torch.nn.Sequential(
            torch.nn.Linear(self.embed_dim, self.embed_dim*2),            
            torch.nn.ReLU6(),
            # torch.nn.Linear(self.embed_dim*2, self.pred_len*self.pred_num*d_dim),
        )
        self.reg_head_outs = nn.ModuleList([torch.nn.Linear(self.embed_dim*2, self.pred_len*2) for _ in range(self.pred_num)])
        

    def forward(self,agent, neighbor=None, modality_labels=None):
        neighbor = neighbor.permute(0,2,1,3)
        agent_loc = agent[...,:2]
        neighbor_loc = neighbor[:,:,:8,:2] # B,Nnum,20,2
        neighbor_dist = torch.norm(neighbor,dim=-1).sum(-1)
        mask = neighbor_dist>1e-3
        neighbor_valid = neighbor_loc* mask[:,:,None,None]
        batch_size, obs_len, in_size = agent_loc.shape
        neighbor_num = neighbor.size(1)
        
        feat,motion,delta,att_mask = dynamic_emb(agent, neighbor, ob_radius=2,gt=None)
        '''
            feat b,Nnum,obs-1,3
            motion: [b,obs-1,2;;;b,obs-1,2]
            delta: [512, 54, 7, 2;;;512, 54, 7, 2]
        '''
        motion = torch.cat(motion,dim=-1)
        delta = torch.cat(delta,dim=-1)
        
        
        feat_emb = self.embed_feat(feat.reshape(batch_size,neighbor_num,-1)) # B,Nnum embsize
        motion_emb = self.embed_motion(motion.reshape(batch_size,-1))# B embsize
        delta_emb = self.embed_delta(delta.reshape(batch_size,neighbor_num,-1))# B,Nnum embsize
        
        mode_num = modality_labels.size(0)
        # ax = agent_loc.reshape(batch_size,-1)
        # dest_emb = self.dest_embedding(modality_labels) # b, 20, 2 -> b,20, emb
        
        # mode_emb = self.motion_mode_embedding(modality_labels.reshape(mode_num,-1))
        
        
        neighbor_emb = self.neighbor_embedding(neighbor_loc.reshape(batch_size,neighbor_num,-1))
        
        agent_loc = agent_loc[:,None,:,:].repeat(1,mode_num,1,1) # B 20 8 2
        modality_labels = modality_labels[None,:,:,:].repeat(batch_size,1,1,1) # B 20 12 2
        ax = torch.cat([agent_loc, modality_labels], dim=2)
        ax = ax.reshape(batch_size, mode_num, -1)
        agent_embedding = self.agent_embedding(ax)
        # mode_emb = mode_emb[None,:,:].repeat(batch_size,1,1)
        # agent_embedding = torch.cat([agent_embedding, mode_emb],dim=-1)
        
        # agent_embedding = self.enc_fc(agent_embedding)
        
        spa_int = self.spa_int_enc(q=agent_embedding, k=agent_embedding, v=agent_embedding, valid_mask=None, att_mask=None) # [batch_size embed_size]
        
        dec_out = self.spa_att_dec(agent_embedding, spa_int, valid_mask=None, cross_att_mask=None)
        
        # dec_out = self.spa_att_dec(spa_int, neighbor_emb, valid_mask=None, cross_att_mask=None)
        # b emb
        
        emb = dec_out.squeeze()
        
        # dec_out = dec_out.repeat(1,self.pred_num,1) # b,20 emb
        # dec_out += dest_emb[None,:,:]  
        PRED = []
        for p in range(self.pred_num):
            reg_emb = self.reg_head_in(emb[:,p])
            pred = (self.reg_head_outs[p](reg_emb)).reshape(batch_size,1,12,2)
            PRED.append(pred)
        pred = torch.cat(PRED,dim=1)
        # pred = self.reg_head(dec_out.reshape(batch_size, -1))
        
        # pred_trajs = pred[:,:self.pred_len*2*self.pred_num].reshape(batch_size, self.pred_num, self.pred_len, 2)
        pred_trajs = torch.cumsum(pred, dim=2)

        pred_prob = self.prob_head(emb.mean(dim=1))
        # ipdb.set_trace()
        # if not self.training :
        # # if True :    
        #     pred_prob, top_indices = torch.topk(pred_prob, k=20, dim=1, largest=True)
            
        #     gather_traj = pred_trajs.clone()
        #     for b_idx in range(batch_size):
        #         for i in range(20):
        #             gather_traj[b_idx][i] = pred_trajs[b_idx][top_indices[b_idx][i]]
        #     pred_trajs = gather_traj[:,:20]
        
        return pred_trajs, pred_prob
    
    def get_loss(self, pred_trajs, gt_trajs, modality_labels=None,static_modes=None):
        '''
        pred_trajs: B, pred_num, pred_len, 2
        gt_trajs: B, pred_len, 2
        '''
        if static_modes is not None:
            high_modes, low_modes = static_modes
        loss = {'total':0}
        err = torch.norm(pred_trajs - gt_trajs.unsqueeze(1), dim=-1) # [batch_size pred_num pred_len]
        distance = err.mean(dim=-1) # batch_size pred_num
        mon_indices = torch.min(distance, dim=-1)[1]
        
        gt_dist = torch.norm(modality_labels[None,:,:,:] - gt_trajs.unsqueeze(1), dim=-1)
        gt_dist = gt_dist.mean(dim=-1)
        mode_indices = torch.min(gt_dist, dim=-1)[1]
        
        
        final_indices = [value if value in low_modes else mon_indices[i] for i,value in enumerate(mode_indices)]
        # ipdb.set_trace()
        reg_loss = err[torch.LongTensor(range(len(final_indices))), final_indices] # [batch_size]
        loss['variety'] = reg_loss.mean()
        loss['total'] += loss['variety']
        
        return loss
    
    def get_prob_loss(self,loss, pred_trajs, gt_trajs, score,pred_prob,modality_labels=None):
        
        err = torch.norm(pred_trajs - gt_trajs.unsqueeze(1), dim=-1) # [batch_size pred_num pred_len]
        # err = torch.norm(pred_trajs - batch_label.unsqueeze(1), dim=-1)
        distance = err.mean(dim=-1) # batch_size pred_num
        # dist_score = self.softmax(-gt_dist)
        dist_score = self.softmax(-distance) 
        
        loss['ce'] = self.ce_loss(pred_prob, dist_score)
        # loss['ce'] = F.binary_cross_entropy(pred_prob, dist_score,reduction='mean')
        loss['total'] += 0.1*loss['ce']
        return loss


class DistributionModel(nn.Module):
    class P_Z(torch.nn.Module):
        def __init__(self, hidden_dim_fy, embed_dim, z_dim):
            super().__init__()
            self.embed = torch.nn.Sequential(
                torch.nn.Linear(hidden_dim_fy, embed_dim),
                torch.nn.ReLU6(),
                torch.nn.Linear(embed_dim, embed_dim),
                torch.nn.ReLU6()
            )
            self.mu = torch.nn.Linear(embed_dim, z_dim)
            self.std = torch.nn.Sequential(
                torch.nn.Linear(embed_dim, z_dim),
                torch.nn.Softplus()
            )
            
        def forward(self, x):
            x = self.embed(x)
            loc = self.mu(x)
            std = self.std(x)
            return torch.distributions.Normal(loc, std)
    
    def __init__(self, in_size, obs_len, pred_len, embed_size=64, num_spa_int_layer=1, heads=4, forward_expansion=2,lamb=0.1):
        super(DistributionModel, self).__init__()
        
        self.obs_len = obs_len
        self.pred_len = pred_len
        self.pred_num = 20
        z_dim = 32

        self.embed_dim = embed_size
        self.islinear = False
        
        self.sampler = DistributionModel.P_Z(embed_size, embed_size, z_dim)
        
        
        self.agent_embedding = nn.Sequential(
            nn.Linear(in_size*(obs_len), embed_size),
            nn.ReLU(),
            nn.Linear(embed_size, embed_size),
        )
                
        self.prob_head = torch.nn.Sequential(
            torch.nn.Linear(self.embed_dim, self.embed_dim*2),            
            torch.nn.ReLU6(),
            torch.nn.Linear(self.embed_dim*2, self.pred_num),
            nn.Softmax(dim=-1)
        ) 
        self.spa_int_enc = Encoder(embed_size, num_spa_int_layer, heads, forward_expansion, islinear=self.islinear)

        self.spa_att_dec = Decoder(embed_size, num_spa_int_layer, heads, forward_expansion, islinear=self.islinear)
        
        
        self.reg_head = nn.Sequential(
            nn.Linear(z_dim, z_dim*2),
            nn.ReLU(),
            nn.Linear(z_dim*2, self.pred_len*2)
        )
        self.att_score = None
        self.softmax = nn.Softmax(dim=-1)
        self.ce_loss = nn.CrossEntropyLoss()
        
        

    def forward(self,agent, neighbor=None, modality_labels=None):
        agent = agent[...,:2]
        batch_size, obs_len, in_size = agent.shape
        
        ax = agent.reshape(batch_size,-1)
        agent_embedding = self.agent_embedding(ax).unsqueeze(1)

        spa_int = self.spa_int_enc(agent_embedding,agent_embedding,agent_embedding, valid_mask=None, att_mask=None) # [batch_size embed_size]
        
        dec_out = self.spa_att_dec(agent_embedding, spa_int, valid_mask=None, cross_att_mask=None).squeeze()
        emb = dec_out.squeeze()
        
        sampler = self.sampler(dec_out)
        
        
        PRED = []
        for p in range(self.pred_num):
           
            z = sampler.rsample()
            pred = self.reg_head(z).reshape(batch_size,1,self.pred_len,2)
            PRED.append(pred)
        pred = torch.cat(PRED,dim=1)
        # pred = self.reg_head(dec_out.reshape(batch_size, -1))
        
        # pred_trajs = pred[:,:self.pred_len*2*self.pred_num].reshape(batch_size, self.pred_num, self.pred_len, 2)
        pred_trajs = torch.cumsum(pred, dim=2)

        # emb = emb.mean(dim=0)
        # emb = emb[None,:].repeat(batch_size,1)
        pred_prob = self.prob_head(emb)
        # if not self.training :
        # # if True :    
        #     pred_prob, top_indices = torch.topk(pred_prob, k=20, dim=1, largest=True)
            
        #     gather_traj = pred_trajs.clone()
        #     for b_idx in range(batch_size):
        #         for i in range(20):
        #             gather_traj[b_idx][i] = pred_trajs[b_idx][top_indices[b_idx][i]]
        #     pred_trajs = gather_traj[:,:20]
        
        return pred_trajs, pred_prob
    
    def get_loss(self, pred_trajs, gt_trajs, modality_labels=None,static_modes = None):
        '''
        pred_trajs: B, pred_num, pred_len, 2
        gt_trajs: B, pred_len, 2
        '''
        
        loss = {'total':0}
        err = torch.norm(pred_trajs - gt_trajs.unsqueeze(1), dim=-1) # [batch_size pred_num pred_len]
        distance = err.mean(dim=-1) # batch_size pred_num
        
        # gt_dist = torch.norm(modality_labels[None,:,:,:] - gt_trajs.unsqueeze(1), dim=-1)
        closest_indices = torch.min(distance, dim=-1)[1]
        # gt_dist = gt_dist.mean(dim=-1)
        
        # closest_indices = torch.min(gt_dist, dim=-1)[1]
        reg_loss = err[torch.LongTensor(range(closest_indices.shape[0])), closest_indices] # [batch_size]
        loss['variety'] = reg_loss.mean()
        loss['total'] += loss['variety']
        
        return loss
    
    def get_prob_loss(self,loss, pred_trajs, gt_trajs, score,pred_prob,modality_labels=None,static_modes = None):
        err = torch.norm(pred_trajs - gt_trajs.unsqueeze(1), dim=-1) # [batch_size pred_num pred_len]
        distance = err.mean(dim=-1) # batch_size pred_num
        dist_score = self.softmax(-distance) 
        # quantiles = torch.quantile(dist_score, q=0.75, dim=1)
        # quantiles = quantiles[:,None].repeat(1,20)
        
        # binary_score = dist_score > quantiles
        # # max_indices = torch.argmax(dist_score, dim=1)
        # label = binary_score.to(torch.float)

        # prob = pred_prob+ score
        # prob = self.softmax(prob)
        
        loss['ce'] = self.ce_loss(pred_prob, dist_score)
        # loss['ce'] = F.binary_cross_entropy(pred_prob, dist_score,reduction='mean')
        loss['total'] += 0.1*loss['ce']
        
        # kl_divergence = F.kl_div(pred_prob.log(), dist_score, reduction='batchmean')
        # loss['kl'] = kl_divergence
        # loss['total'] += loss['kl'] 
        return loss

class SoftModel(nn.Module):
    
    def __init__(self, in_size, obs_len, pred_len, embed_size=64, num_spa_int_layer=1, heads=4, forward_expansion=2,lamb=0.1):
        super(SoftModel, self).__init__()
        
        self.obs_len = obs_len
        self.pred_len = pred_len
        self.pred_num = 20
        self.select_num = 20
        self.lamb = lamb

        self.embed_dim = embed_size
        self.islinear = False
        
        self.motion_mode_embedding = nn.Sequential(
            nn.Linear(in_size*(pred_len), embed_size),
            nn.ReLU(),
            nn.Linear(embed_size, embed_size),
        )
        
        self.agent_embedding = nn.Sequential(
            nn.Linear(in_size*(obs_len), embed_size),
            nn.ReLU(),
            nn.Linear(embed_size, embed_size),
        )
        
        self.enc_fc = nn.Linear(2*embed_size, embed_size)
        
        self.prob_head = torch.nn.Sequential(
            torch.nn.Linear(self.embed_dim, self.embed_dim*2),            
            torch.nn.ReLU6(),
            torch.nn.Linear(self.embed_dim*2, self.pred_num),
            nn.Softmax(dim=-1)
        ) 
        self.spa_int_enc = Encoder(embed_size, num_spa_int_layer, heads, forward_expansion, islinear=self.islinear)

        self.spa_att_dec = Decoder(embed_size, num_spa_int_layer, heads, forward_expansion, islinear=self.islinear)
        
        self.dest_embedding = nn.Sequential(
            nn.Linear(2, embed_size),
            nn.ReLU(),
            nn.Linear(embed_size, embed_size)
        )
        
        self.reg_head = nn.Sequential(
            nn.Linear(embed_size, embed_size*2),
            nn.ReLU(),
            nn.Linear(embed_size*2, self.pred_len*2*self.pred_num)
        )
        self.att_score = None
        self.criterion = nn.SmoothL1Loss(reduction='mean')
        self.softmax = nn.Softmax(dim=-1)
        self.ce_loss = nn.CrossEntropyLoss()
        
        self.reg_head_in = torch.nn.Sequential(
            torch.nn.Linear(self.embed_dim, self.embed_dim*2),            
            torch.nn.ReLU6(),
            # torch.nn.Linear(self.embed_dim*2, self.pred_len*self.pred_num*d_dim),
        )
        # self.reg_head_outs = nn.ModuleList([
        #     torch.nn.Sequential(
        #     torch.nn.Linear(self.embed_dim, self.embed_dim*2),            
        #     torch.nn.ReLU6(),
        #     torch.nn.Linear(self.embed_dim*2, self.pred_len*2)
        #     )
        #     for _ in range(self.pred_num)])
        
        self.reg_head_outs = nn.ModuleList([
             torch.nn.Linear(self.embed_dim*2, self.pred_len*2)
            for _ in range(self.pred_num)])
        
        self.query_outs = nn.ModuleList([
            torch.nn.Sequential(
            torch.nn.Linear(self.embed_dim, self.embed_dim*2),            
            torch.nn.ReLU6(),
            )
            for _ in range(self.pred_num)])
        
    def forward(self,agent, neighbor=None, modality_labels=None):
        agent = agent[...,:2]
        batch_size, obs_len, in_size = agent.shape
        if neighbor is not None:
            Nn = neighbor.size(2)
            neighbor = neighbor[:,:obs_len,:, :in_size].permute(0,2,1,3)
            nei = neighbor.reshape(batch_size,Nn,-1)
            neighbor_embedding = self.agent_embedding(nei)
            var_pos = agent.unsqueeze(1) - neighbor
            dist = var_pos.norm(dim=-1).sum(-1) 
            mask = dist < 1e4
        # mode_num = modality_labels.size(0)
        ax = agent.reshape(batch_size,-1)
        
        
        
        
        agent_embedding = self.agent_embedding(ax).unsqueeze(1)
        # mode_emb = mode_emb[None,:,:].repeat(batch_size,1,1)
        # agent_embedding = torch.cat([agent_embedding, mode_emb],dim=-1)
        
        # agent_embedding = self.enc_fc(agent_embedding)
        
        spa_int = self.spa_int_enc(agent_embedding,neighbor_embedding,neighbor_embedding, valid_mask=None, att_mask=mask) # [batch_size embed_size]
        # spa_int = self.spa_int_enc(agent_embedding,agent_embedding,agent_embedding, valid_mask=None, att_mask=None) # [batch_size embed_size]
        
        dec_out = self.spa_att_dec(agent_embedding, spa_int, valid_mask=None, cross_att_mask=None).squeeze()
        # b emb
        emb = dec_out.squeeze()
        # dec_out = dec_out.repeat(1,self.pred_num,1) # b,20 emb
        # dec_out += dest_emb[None,:,:] # 
        PRED = []
        mode_querys = []
        for p in range(self.pred_num):
            mode_query = self.query_outs[p](emb)
            mode_querys.append(mode_query[:,None,:])
        mode_querys = torch.cat(mode_querys, dim=1)
        score, mode_outs = self.self_attention(mode_querys,mode_querys,mode_querys)
        
        for p in range(self.pred_num):
            pred = (self.reg_head_outs[p](mode_outs[:,p])).reshape(batch_size,1,12,2)
            PRED.append(pred)
            
        pred = torch.cat(PRED,dim=1)
        pred_trajs = torch.cumsum(pred, dim=2)
        # pred = self.reg_head(dec_out.reshape(batch_size, -1))
        
        # pred_trajs = pred[:,:self.pred_len*2*self.pred_num].reshape(batch_size, self.pred_num, self.pred_len, 2)
        

        # emb = emb.mean(dim=0)
        # emb = emb[None,:].repeat(batch_size,1)
        pred_prob = self.prob_head(emb)
        # if not self.training :
        # # if True :    
        #     pred_prob, top_indices = torch.topk(pred_prob, k=20, dim=1, largest=True)
            
        #     gather_traj = pred_trajs.clone()
        #     for b_idx in range(batch_size):
        #         for i in range(20):
        #             gather_traj[b_idx][i] = pred_trajs[b_idx][top_indices[b_idx][i]]
        #     pred_trajs = gather_traj[:,:20]
        if not self.training:
            _, pred_ind = torch.topk(pred_prob, k = self.select_num, dim=-1)
            pred_ind = pred_ind.to(pred_prob.device)
            # pred_prob = pred_prob.gather(1, pred_ind)
            # pred_trajs = pred_trajs[torch.arange(pred_trajs.size(0))[:, None, None], torch.arange(pred_trajs.size(2))[None, None, :], pred_ind[:, :, None], :]
            for i in range(self.select_num):
                pred_prob[:,i] = pred_prob[torch.LongTensor(range(pred_ind.shape[0])),pred_ind[:,i]]
                pred_trajs[:,i] = pred_trajs[torch.LongTensor(range(pred_ind.shape[0])),pred_ind[:,i]]
                
            pred_prob = pred_prob[:,:self.select_num]
            pred_trajs = pred_trajs[:,:self.select_num]
            

            
        return pred_trajs, pred_prob
    
    def get_loss(self, pred_trajs, gt_trajs,pred_prob=None, modality_labels=None, static_modes=None):
        '''
        pred_trajs: B, pred_num, pred_len, 2
        gt_trajs: B, pred_len, 2
        '''
        
        loss = {'total':0}
        err = torch.norm(pred_trajs - gt_trajs.unsqueeze(1), dim=-1) # [batch_size pred_num pred_len]
        distance = err.mean(dim=-1) # batch_size pred_num
        
        # gt_dist = torch.norm(modality_labels[None,:,:,:] - gt_trajs.unsqueeze(1), dim=-1)
        closest_indices = torch.min(distance, dim=-1)[1]
        # closest_indices = torch.max(pred_prob, dim=-1)[1]
        # gt_dist = gt_dist.mean(dim=-1)
        
        # closest_indices = torch.min(gt_dist, dim=-1)[1]
        _, topk_indice = torch.topk(distance, k = 2, dim=-1)
      
        reg_loss = distance.gather(1, topk_indice)
        # reg_loss = err[torch.LongTensor(range(closest_indices.shape[0])), closest_indices] # [batch_size]
        closest_pred = pred_trajs[torch.LongTensor(range(closest_indices.shape[0])), closest_indices]
        
        # reg_loss = self.criterion(closest_pred, gt_trajs)
        
        loss['variety'] = reg_loss.mean()
        loss['total'] += loss['variety']
        
        return loss
    
    def get_prob_loss(self,loss, pred_trajs, gt_trajs, score,pred_prob, modality_labels=None):
        err = torch.norm(pred_trajs - gt_trajs.unsqueeze(1), dim=-1) # [batch_size pred_num pred_len]
        distance = err.mean(dim=-1) # batch_size pred_num 
        dist_score = self.softmax(-distance) 
        # quantiles = torch.quantile(dist_score, q=0.75, dim=1) 
        # quantiles = quantiles[:,None].repeat(1,20)
        
        # binary_score = dist_score > quantiles
        # # max_indices = torch.argmax(dist_score, dim=1)
        # label = binary_score.to(torch.float)

        # prob = pred_prob+ score
        # prob = self.softmax(prob)
        
        loss['ce'] = self.ce_loss(pred_prob, dist_score)
        # ipdb.set_trace()
        # loss['ce'] = F.binary_cross_entropy(pred_prob, dist_score,reduction='mean')
       
        loss['total'] += self.lamb *loss['ce']
        
        # kl_divergence = F.kl_div(pred_prob.log(), dist_score, reduction='batchmean')
        # loss['kl'] = kl_divergence
        # loss['total'] += loss['kl'] 
        return loss
    
    def self_attention(self, query,key,value, mask=None, dropout=None):
        # q: Bx emb
        # k: B x Nnum x emb
        # mask: B x Nnum
        attention_nonlinearity = torch.nn.LeakyReLU(0.2)
        
        score = (key @ query.permute(0,2,1)).squeeze(-1)           # N x Nn
        score = attention_nonlinearity(score)              # N x Nn
        if mask is not None:
            score[~mask] = -float("inf")
        score = torch.nn.functional.softmax(score, dim=-1).nan_to_num()    # N x Nn
        
        if dropout is not None:
            score = dropout(score)
            
        logits = score @ value
        return score, logits
  
        
class RNNModel_new(nn.Module):
    
    class RNNDec(torch.nn.Module):
            def __init__(self, feat_dim, d_dim):
                super().__init__()
                self.rnn = torch.nn.GRU(feat_dim, feat_dim)
                self.step_dec = torch.nn.Sequential(
                        nn.Linear(feat_dim, feat_dim),
                        nn.ReLU(),
                        nn.Linear(feat_dim, d_dim),
                    )
                
                
            def forward(self, feat):
                # h = feat.clone()
                
                _, hidden = self.rnn(feat[None,:,:])
                step_d = self.step_dec(hidden)
                
                return step_d, hidden
            
    def __init__(self, in_size, obs_len, pred_len, embed_size=64, num_spa_int_layer=1, heads=4, forward_expansion=2,lamb=0.1):
        super().__init__()
        
        
        self.obs_len = obs_len
        self.pred_len = pred_len
        self.pred_num = 20
        d_dim = 2

        self.embed_dim = embed_size
        self.islinear = False
        
        self.motion_mode_embedding = nn.Sequential(
            nn.Linear(in_size*(pred_len), embed_size),
            nn.ReLU(),
            nn.Linear(embed_size, embed_size),
        )
        
        self.agent_embedding = nn.Sequential(
            nn.Linear(in_size*(obs_len), embed_size),
            nn.ReLU(),
            nn.Linear(embed_size, embed_size),
        )
        
        self.enc_fc = nn.Linear(2*embed_size, embed_size)
        
        self.prob_head = torch.nn.Sequential(
            torch.nn.Linear(self.embed_dim, self.embed_dim*2),            
            torch.nn.ReLU6(),
            torch.nn.Linear(self.embed_dim*2, self.pred_num),
            nn.Softmax(dim=-1)
        ) 
        self.spa_int_enc = Encoder(embed_size, num_spa_int_layer, heads, forward_expansion, islinear=self.islinear)

        self.spa_att_dec = Decoder(embed_size, num_spa_int_layer, heads, forward_expansion, islinear=self.islinear)
        
        self.dest_embedding = nn.Sequential(
            nn.Linear(2, embed_size),
            nn.ReLU(),
            nn.Linear(embed_size, embed_size)
        )
        
        self.reg_head = nn.Sequential(
            nn.Linear(embed_size, embed_size*2),
            nn.ReLU(),
            nn.Linear(embed_size*2, self.pred_len*2*self.pred_num)
        )
        self.att_score = None
        self.softmax = nn.Softmax(dim=-1)
        self.ce_loss = nn.CrossEntropyLoss()
        
        self.rnn_enc = nn.GRU(input_size=2, hidden_size=256, num_layers=1, batch_first=True)

        
        
        self.lstm_heads = nn.ModuleList([
                self.RNNDec(embed_size, d_dim)
            for _ in range(self.pred_num)])
        
        

    def forward(self,agent, neighbor=None, modality_labels=None):
        agent = agent[...,:2]
        batch_size, obs_len, in_size = agent.shape
      
        ax = agent.reshape(batch_size,-1)
        # dest_emb = self.dest_embedding(modality_labels) # b, 20, 2 -> b,20, emb
        
        
        
        
        agent_embedding = self.agent_embedding(ax).unsqueeze(1)
        
        spa_int = self.spa_int_enc(agent_embedding,agent_embedding,agent_embedding, valid_mask=None, att_mask=None) # [batch_size embed_size]
        
        dec_out = self.spa_att_dec(agent_embedding, spa_int, valid_mask=None, cross_att_mask=None).squeeze()
        # b emb
        emb = dec_out.squeeze()

        PRED = []
        agents = torch.zeros(batch_size,self.pred_num,obs_len+self.pred_len,in_size).to(agent.device)
        for p in range(self.pred_num):
            pred = torch.zeros(batch_size,1,12,2).to(agent.device)
            feat = emb
            hidden = torch.zeros_like(feat)
            for t in range(self.pred_len):
                feat = feat +hidden.squeeze()
                step_d, hidden = self.lstm_heads[p](feat)
                
                pred[:,0,t,:] = step_d
            PRED.append(pred)
        pred = torch.cat(PRED,dim=1)
        # pred = self.reg_head(dec_out.reshape(batch_size, -1))
        
        # pred_trajs = pred[:,:self.pred_len*2*self.pred_num].reshape(batch_size, self.pred_num, self.pred_len, 2)
        pred_trajs = torch.cumsum(pred, dim=2)

        # emb = emb.mean(dim=0)
        # emb = emb[None,:].repeat(batch_size,1)
        pred_prob = self.prob_head(emb)

        
        return pred_trajs, pred_prob
    
    def get_loss(self, pred_trajs, gt_trajs, modality_labels=None, static_modes=None):
        '''
        pred_trajs: B, pred_num, pred_len, 2
        gt_trajs: B, pred_len, 2
        '''
        
        loss = {'total':0}
        err = torch.norm(pred_trajs - gt_trajs.unsqueeze(1), dim=-1) # [batch_size pred_num pred_len]
        distance = err.mean(dim=-1) # batch_size pred_num
        
        # gt_dist = torch.norm(modality_labels[None,:,:,:] - gt_trajs.unsqueeze(1), dim=-1)
        closest_indices = torch.min(distance, dim=-1)[1]
        # gt_dist = gt_dist.mean(dim=-1)
        
        # closest_indices = torch.min(gt_dist, dim=-1)[1]
        reg_loss = err[torch.LongTensor(range(closest_indices.shape[0])), closest_indices] # [batch_size]
        loss['variety'] = reg_loss.mean()
        loss['total'] += loss['variety']
        
        return loss
    
    def get_prob_loss(self,loss, pred_trajs, gt_trajs, score,pred_prob, modality_labels=None):
        err = torch.norm(pred_trajs - gt_trajs.unsqueeze(1), dim=-1) # [batch_size pred_num pred_len]
        distance = err.mean(dim=-1) # batch_size pred_num 
        dist_score = self.softmax(-distance) 

        
        loss['ce'] = self.ce_loss(pred_prob, dist_score)
        # loss['ce'] = F.binary_cross_entropy(pred_prob, dist_score,reduction='mean')
        loss['total'] += 0.1*loss['ce']

        return loss  
        
class DynamicModel(nn.Module):
    
    def __init__(self, in_size, obs_len, pred_len, config=None, embed_size=64, num_spa_int_layer=1, heads=4, forward_expansion=2,lamb=0.1):
        super(DynamicModel, self).__init__()
        
        self.obs_len = obs_len
        self.pred_len = pred_len
        if config is not None:
            self.ob_radius = config.OB_RADIUS
        self.pred_num = 20

        self.embed_dim = embed_size
        self.islinear = False
        
        
        self.w_query = nn.Linear(in_size*(obs_len), embed_size)
        self.w_key = nn.Linear(3*(obs_len-1), embed_size)
        self.w_value = nn.Linear(2*in_size*(obs_len-1), embed_size)
        
        self.motion_mode_embedding = nn.Sequential(
            nn.Linear(in_size*(pred_len), embed_size),
            nn.ReLU(),
            nn.Linear(embed_size, embed_size),
        )
        
        self.agent_embedding = nn.Sequential(
            nn.Linear(in_size*(obs_len), embed_size),
            nn.ReLU(),
            nn.Linear(embed_size, embed_size),
        )
        
        self.enc_fc = nn.Linear(2*embed_size, embed_size)
        
        self.prob_head = torch.nn.Sequential(
            torch.nn.Linear(self.embed_dim, self.embed_dim*2),            
            torch.nn.ReLU6(),
            torch.nn.Linear(self.embed_dim*2, self.pred_num),
            nn.Softmax(dim=-1)
        ) 
        self.spa_int_enc = Encoder(embed_size, num_spa_int_layer, heads, forward_expansion, islinear=self.islinear)

        self.spa_att_dec = Decoder(embed_size, num_spa_int_layer, heads, forward_expansion, islinear=self.islinear)
        
        self.dest_embedding = nn.Sequential(
            nn.Linear(2, embed_size),
            nn.ReLU(),
            nn.Linear(embed_size, embed_size)
        )
        
        self.reg_head = nn.Sequential(
            nn.Linear(embed_size, embed_size*2),
            nn.ReLU(),
            nn.Linear(embed_size*2, self.pred_len*2*self.pred_num)
        )
        self.att_score = None
        self.criterion = nn.SmoothL1Loss(reduction='mean')
        self.softmax = nn.Softmax(dim=-1)
        self.ce_loss = nn.CrossEntropyLoss()
        
        self.reg_head_in = torch.nn.Sequential(
            torch.nn.Linear(self.embed_dim, self.embed_dim*2),            
            torch.nn.ReLU6(),
            # torch.nn.Linear(self.embed_dim*2, self.pred_len*self.pred_num*d_dim),
        )
        # self.reg_head_outs = nn.ModuleList([
        #     torch.nn.Sequential(
        #     torch.nn.Linear(self.embed_dim, self.embed_dim*2),            
        #     torch.nn.ReLU6(),
        #     torch.nn.Linear(self.embed_dim*2, self.pred_len*2)
        #     )
        #     for _ in range(self.pred_num)])
        
        self.reg_head_outs = nn.ModuleList([
             torch.nn.Linear(self.embed_dim*2, self.pred_len*2)
            for _ in range(self.pred_num)])
        
        self.query_outs = nn.ModuleList([
            torch.nn.Sequential(
            torch.nn.Linear(self.embed_dim, self.embed_dim*2),            
            torch.nn.ReLU6(),
            )
            for _ in range(self.pred_num)])
        
    def dynamic_enc(self, agent, neighbor):
        agent = agent.permute(1,0,2)
        neighbor = neighbor.permute(1,0,2,3)
        
        with torch.no_grad():
            L1 = agent.size(0)-1
            neighbor = neighbor[:L1+1]
            N = neighbor.size(1)
            Nn = neighbor.size(2)
            state = agent

            agent = state[...,:2]                       # (L1+1) x N x 2
            L2 = 0
            
                
            
            v = agent[1:] - agent[:-1]                      # L x N x 2
            a = v[1:] - v[:-1]                      # (L-1) x N x 2
            a = torch.cat((state[1:2,...,4:6], a))  # L x N x 2

            neighbor_x = neighbor[...,:2]           # (L+1) x N x Nn x 2
            neighbor_v = neighbor[1:,...,2:4]       # L x N x Nn x 2
            
            dp = neighbor_x - agent.unsqueeze(-2)       # (L+1) x N x Nn x 2
            dv = neighbor_v - v.unsqueeze(-2)       # L x N x Nn x 2

            # social features
            dist = dp.norm(dim=-1)                          # (L+1) x N x Nn
            mask = dist <= self.ob_radius
            mask = torch.prod(mask, dim=0)
            
            # dp0, mask0 = dp[0], mask[0]
            dp = dp[1:]
            dist = dist[1:]
            
            dot_dp_v = (dp @ v.unsqueeze(-1)).squeeze(-1)   # L x N x Nn
            bearing = dot_dp_v / (dist*v.norm(dim=-1).unsqueeze(-1)) # L x N x Nn
            bearing = bearing.nan_to_num(0, 0, 0)
            dot_dp_dv = (dp.unsqueeze(-2) @ dv.unsqueeze(-1)).view(dp.size(0),N,Nn)
            tau = -dot_dp_dv / dv.norm(dim=-1)              # L x N x Nn
            tau = tau.nan_to_num(0, 0, 0).clip(0, 7)
            mpd = (dp + tau.unsqueeze(-1)*dv).norm(dim=-1)  # L x N x Nn
            features = torch.stack((dist, bearing, mpd), -1)# L x N x Nn x 3
            key = features.permute(1,2,0,3) # B, Nn, obs_len-1, 3
        
        query = dp.permute(1,2,0,3)
        value = (torch.cat((dp, dv), -1)).permute(1,2,0,3)
        agent_s = (torch.cat((v, a), -1)).permute(1,0,2)
        
        
        return query, key, value, mask
        
    def forward(self,agent, neighbor=None, modality_labels=None):
        
        query, key, value, mask = self.dynamic_enc(agent=agent, neighbor=neighbor)
        Nn = neighbor.size(2)
        agent = agent[...,:2]
        batch_size, obs_len, in_size = agent.shape
        # mode_num = modality_labels.size(0)
        ax = agent.reshape(batch_size,-1)
        # dest_emb = self.dest_embedding(modality_labels) # b, 20, 2 -> b,20, emb
        
        # mode_emb = self.motion_mode_embedding(modality_labels.reshape(mode_num,-1))
        agent_embedding = self.agent_embedding(ax).unsqueeze(1)
        # mode_emb = mode_emb[None,:,:].repeat(batch_size,1,1)
        # agent_embedding = torch.cat([agent_embedding, mode_emb],dim=-1)
        # agent_embedding = self.enc_fc(agent_embedding)
        
        query = self.w_query(ax).unsqueeze(1)
        key = self.w_key(key.reshape(batch_size,Nn,-1))
        value = self.w_value(value.reshape(batch_size,Nn,-1))
        
        spa_int = self.spa_int_enc(agent_embedding,key,value, valid_mask=None, att_mask=mask) # [batch_size embed_size]
        # spa_int = self.spa_int_enc(query,key,value, valid_mask=None, att_mask=None)
        
        dec_out = self.spa_att_dec(agent_embedding, spa_int, valid_mask=None, cross_att_mask=None).squeeze()
        # b emb
        emb = dec_out.squeeze()
        # dec_out = dec_out.repeat(1,self.pred_num,1) # b,20 emb
        # dec_out += dest_emb[None,:,:] # 
        PRED = []
        mode_querys = []
        for p in range(self.pred_num):
            mode_query = self.query_outs[p](emb)
            mode_querys.append(mode_query[:,None,:])
        mode_querys = torch.cat(mode_querys, dim=1)
        # score, mode_outs = self.self_attention(mode_querys,mode_querys,mode_querys)
        
        for p in range(self.pred_num):
            pred = (self.reg_head_outs[p](mode_querys[:,p])).reshape(batch_size,1,12,2)
            PRED.append(pred)
            
        pred = torch.cat(PRED,dim=1)
        pred_trajs = torch.cumsum(pred, dim=2)
        # pred = self.reg_head(dec_out.reshape(batch_size, -1))
        
        # pred_trajs = pred[:,:self.pred_len*2*self.pred_num].reshape(batch_size, self.pred_num, self.pred_len, 2)
        

        # emb = emb.mean(dim=0)
        # emb = emb[None,:].repeat(batch_size,1)
        pred_prob = self.prob_head(emb)
        # if not self.training :
        # # if True :    
        #     pred_prob, top_indices = torch.topk(pred_prob, k=20, dim=1, largest=True)
            
        #     gather_traj = pred_trajs.clone()
        #     for b_idx in range(batch_size):
        #         for i in range(20):
        #             gather_traj[b_idx][i] = pred_trajs[b_idx][top_indices[b_idx][i]]
        #     pred_trajs = gather_traj[:,:20]
        
        return pred_trajs, pred_prob
    
    def get_loss(self, pred_trajs, gt_trajs,pred_prob=None, modality_labels=None, static_modes=None):
        '''
        pred_trajs: B, pred_num, pred_len, 2
        gt_trajs: B, pred_len, 2
        '''
        
        loss = {'total':0}
        err = torch.norm(pred_trajs - gt_trajs.unsqueeze(1), dim=-1) # [batch_size pred_num pred_len]
        distance = err.mean(dim=-1) # batch_size pred_num
        
        # gt_dist = torch.norm(modality_labels[None,:,:,:] - gt_trajs.unsqueeze(1), dim=-1)
        closest_indices = torch.min(distance, dim=-1)[1]
        # closest_indices = torch.max(pred_prob, dim=-1)[1]
        # gt_dist = gt_dist.mean(dim=-1)
        
        # closest_indices = torch.min(gt_dist, dim=-1)[1]
        reg_loss = err[torch.LongTensor(range(closest_indices.shape[0])), closest_indices] # [batch_size]
        closest_pred = pred_trajs[torch.LongTensor(range(closest_indices.shape[0])), closest_indices]
        
        # reg_loss = self.criterion(closest_pred, gt_trajs)
        
        loss['variety'] = reg_loss.mean()
        loss['total'] += loss['variety']
        
        return loss
    
    def get_prob_loss(self,loss, pred_trajs, gt_trajs, score,pred_prob, modality_labels=None):
        err = torch.norm(pred_trajs - gt_trajs.unsqueeze(1), dim=-1) # [batch_size pred_num pred_len]
        distance = err.mean(dim=-1) # batch_size pred_num 
        dist_score = self.softmax(-distance) 
        # quantiles = torch.quantile(dist_score, q=0.75, dim=1) 
        # quantiles = quantiles[:,None].repeat(1,20)
        
        # binary_score = dist_score > quantiles
        # # max_indices = torch.argmax(dist_score, dim=1)
        # label = binary_score.to(torch.float)

        # prob = pred_prob+ score
        # prob = self.softmax(prob)
        
        loss['ce'] = self.ce_loss(pred_prob, dist_score)
        # ipdb.set_trace()
        # loss['ce'] = F.binary_cross_entropy(pred_prob, dist_score,reduction='mean')
       
        loss['total'] += 0.05*loss['ce']
        
        # kl_divergence = F.kl_div(pred_prob.log(), dist_score, reduction='batchmean')
        # loss['kl'] = kl_divergence
        # loss['total'] += loss['kl'] 
        return loss
    
    def self_attention(self, query,key,value, mask=None, dropout=None):
        # q: Bx emb
        # k: B x Nnum x emb
        # mask: B x Nnum
        attention_nonlinearity = torch.nn.LeakyReLU(0.2)
        
        score = (key @ query.permute(0,2,1)).squeeze(-1)           # N x Nn
        score = attention_nonlinearity(score)              # N x Nn
        if mask is not None:
            score[~mask] = -float("inf")
        score = torch.nn.functional.softmax(score, dim=-1).nan_to_num()    # N x Nn
        
        if dropout is not None:
            score = dropout(score)
            
        logits = score @ value
        return score, logits
    
    
        
        
        
    
        
        
        