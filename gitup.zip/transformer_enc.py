import torch
import torch.nn as nn
import math
from torch.nn import functional as F
import ipdb

class Encoder(nn.Module):
    def __init__(
        self,
        embed_size,
        num_layers,
        heads,
        forward_expansion,
        dropout=0.1,
        islinear=True
    ):
        super(Encoder, self).__init__()

        self.layers = nn.ModuleList(
            [
                TransformerBlock(embed_size, heads, forward_expansion, dropout, islinear=islinear)
                for _ in range(num_layers)
            ]
        )
        self.dropout = nn.Dropout(dropout)

    def forward(self, q,k,v, valid_mask, att_mask=None):

        for layer in self.layers:
            x = layer(q, k, v, valid_mask, att_mask)

        return x


class TransformerBlock(nn.Module):
    def __init__(self, embed_size, head, forward_expansion, dropout, islinear=True):
        super(TransformerBlock, self).__init__()

        self.attn = MultihHeadAttention(embed_size, head, islinear=islinear)
        # self.norm1 = LayerNorm(embed_size)
        self.norm1 = nn.Sequential()
        # self.norm2 = LayerNorm(embed_size)
        self.norm2 = nn.Sequential()
        self.feed_forward = FeedForwardLayer(embed_size, forward_expansion)
        self.dropout = nn.Dropout(dropout)

    def forward(self, query, key, value, valid_mask, mask):
        
        logits = self.attn(query, key, value, valid_mask, mask)
        x = self.dropout(self.norm1(logits + query))
        forward = self.feed_forward(x, valid_mask)
        out = self.dropout(self.norm2(forward + x))
        return out



class FeedForwardLayer(nn.Module):
    def __init__(self, d_model, forward_expansion):
        super(FeedForwardLayer, self).__init__()
        self.w1 = nn.Linear(d_model, d_model*forward_expansion)
        self.w2 = nn.Linear(d_model*forward_expansion, d_model)

    def forward(self, x, valid_mask=None):
        valid_mask=None
        if valid_mask is not None:
            x_valid = x[valid_mask]
        else:
            x_valid = x
        x_valid = self.w2((F.relu(self.w1(x_valid))))
        x_feat = x.new_zeros(x.shape[0], x.shape[1], x_valid.shape[-1])
        if valid_mask is not None:
            x_feat[valid_mask] = x_valid
        else:
            x_feat = x_valid
        
        return x_feat


class LayerNorm(nn.Module):
    def __init__(self, embedding_dim, eps=1e-6):
        super(LayerNorm, self).__init__()
        self.a = nn.Parameter(torch.ones(embedding_dim))
        self.b = nn.Parameter(torch.zeros(embedding_dim))
        self.eps = eps

    def forward(self, x):
        mean = x.mean(-1, keepdim=True)
        std = x.std(-1, keepdim=True)
        return self.a * (x-mean) / (std+self.eps) + self.b


class MultihHeadAttention(nn.Module):
    def __init__(self, d_model, h, dropout=0.1, islinear=True):
        super(MultihHeadAttention, self).__init__()

        assert d_model % h == 0

        self.d_k = d_model // h
        self.h = h

        self.w_key = nn.Linear(d_model, d_model) if islinear else nn.Sequential(nn.Linear(d_model, d_model), nn.ReLU(), nn.Linear(d_model, d_model))
        self.w_query = nn.Linear(d_model, d_model) if islinear else nn.Sequential(nn.Linear(d_model, d_model), nn.ReLU(), nn.Linear(d_model, d_model))
        self.w_value = nn.Linear(d_model, d_model)
        self.fc_out = nn.Linear(d_model, d_model)

        self.dropout = nn.Dropout(dropout)

        self.atten = None  # 返回的attention张量，现在还没有，保存给可视化使用

    def forward(self, query, key, value, valid_mask=None, mask=None):
        # valid_mask: B, Nn
        
        
        if mask is not None:
            adj_matrix = mask.unsqueeze(2) * mask.unsqueeze(1)
            mask = mask.unsqueeze(1)  # head导致query等多了一维
            # b, 1, Nn, Nn
        
        batch_size, seq_len, C = query.shape
        if valid_mask is None :
            query_valid, key_valid, value_valid = query, key, value
            
        else:
            # query_valid  = query[valid_mask]
            query_valid = query
            key_valid, value_valid = key[valid_mask], value[valid_mask]
            
        
        query_valid = self.w_query(query_valid)
        key_valid = self.w_key(key_valid)
        value_valid = self.w_value(value_valid)

        # query = query.new_zeros(batch_size, seq_len, query_valid.shape[-1])
        key = key.new_zeros(batch_size, key.size(1), key_valid.shape[-1])
        value = value.new_zeros(batch_size, value.size(1), value_valid.shape[-1])

        if valid_mask is None :
            query = query_valid
            key = key_valid
            value = value_valid
        else:
            # query[valid_mask] = query_valid
            query = query_valid
            
            key[valid_mask] = key_valid
            value[valid_mask] = value_valid
        
        query = query.view(batch_size, -1, self.h, self.d_k).transpose(1, 2)
        key = key.view(batch_size, -1, self.h, self.d_k).transpose(1, 2)
        value = value.view(batch_size, -1, self.h, self.d_k).transpose(1, 2)

        
        x, self.atten = attention(query, key, value, mask, self.dropout)
        
        x = x.transpose(1, 2).contiguous().view(batch_size, -1, self.h * self.d_k)
        x_valid = x
        # if valid_mask is None:
        #     x_valid = x
        # else:
        #     x_valid = x[valid_mask]
            
        x = self.fc_out(x_valid)
        # x = x.new_zeros(batch_size, seq_len, x_valid.shape[-1])
        
        # if valid_mask is None:
        #     x = x_valid
        # else:
        #     x[valid_mask] = x_valid

        return x



def attention(query, key, value, mask=None, dropout=None):
    '''
    query b,4,1,64
    key b,4,Nn,64
    value b,4,Nn,64
    mask b Nn
    '''
    
    d_k = query.size(-1)
    scores = torch.matmul(query, key.transpose(-2, -1)) / math.sqrt(d_k)
    
    if mask is not None:
        mask = mask.unsqueeze(1)
        scores = scores.masked_fill(mask==0, -1e9) # b 4 1 Nn

    scores = F.softmax(scores, dim=-1)

    if dropout is not None:
        scores = dropout(scores)

    return torch.matmul(scores, value), scores