import torch
import numpy as np
import ipdb
import random
import math
import matplotlib.pyplot as plt 

def ADE_FDE(y_, y, batch_first=True):
    # average displacement error
    # final displacement error
    # y_, y: S x L x N x 2
    if torch.is_tensor(y):
        
        
        err = (y_ - y[:,None,:,:]).norm(dim=-1)
    else:
        err = np.linalg.norm(np.subtract(y_, y), axis=-1)
    if len(err.shape) == 1:
        fde = err[-1]
        ade = err.mean()
    elif batch_first:
        fde = err[..., -1]
        ade = err.mean(-1)
    else:
        fde = err[..., -1, :]
        ade = err.mean(-2)
    return ade, fde

def gen_mask(x,y, mask_len=12, mode='pre_train'):
    '''
        mode: 'pre_train' / 'fine-tune'
    '''
    device = x.device
    
    x = x[..., :2]# b 8 2
    y = y
    batch_size, obs_len, fut_len = x.size(0), x.size(1), y.size(1)
    
    if mode == 'pre_train':
        full_traj = torch.cat([x,y],dim=1) # b 20, 2
        mask_ls = []
        mask_zeros = torch.zeros(int(mask_len))
        
        for b_idx in range(batch_size):
            
            mask_idx = torch.ones(1,full_traj.size(1))
            start_idx = random.randint(1,20-mask_len)
            mask_idx[0,start_idx:start_idx+mask_len] = mask_zeros
            
            mask_ls.append(mask_idx)
        mask = torch.cat(mask_ls,dim=0).to(device).to(torch.int)
        
        masked_traj = full_traj*mask[:,:, None]
        masked_traj = torch.cat([masked_traj, mask[:,:, None]], dim=-1)
        
        
        
        
    elif mode == 'fine-tune':
        full_traj = torch.cat([x,y],dim=1) # b 20, 2
        mask_zeros = torch.zeros([batch_size, fut_len, 2]).to(device).to(torch.int)
        
        full_traj[:,obs_len:,:] = mask_zeros
        aa,bb = torch.ones([batch_size, obs_len, 1]), torch.zeros([batch_size, fut_len, 1])
        mask_idx = torch.cat([aa,bb],dim=1).to(device)
        
        masked_traj = torch.cat([full_traj, mask_idx],dim=-1)
        mask = mask_idx
    
    elif mode == 'test':
        full_traj = torch.cat([x,y],dim=1) # b 20, 2
        mask_zeros = torch.zeros([batch_size, fut_len, 2]).to(device).to(torch.int)
        
        full_traj[:,obs_len:,:] = mask_zeros
        aa,bb = torch.ones([batch_size, obs_len, 1]), torch.zeros([batch_size, fut_len, 1])
        mask_idx = torch.cat([aa,bb],dim=1).to(device)
        
        masked_traj = torch.cat([full_traj, mask_idx],dim=-1)
        mask = mask_idx

    
    
    return masked_traj, mask, full_traj

def gen_toy_dataset(num_samples, noise_std=0.1, angle_degrees=45):
    """
    生成玩具数据集，控制 y 的路径方向与 x 轴的夹角

    参数:
        num_samples (int): 要生成的样本数。
        noise_std (float): 噪声标准差。
        angle_degrees (float): y 路径与 x 轴的夹角（度数）。

    返回:
        x (Tensor): 形状为 [num_samples, 8, 2] 的 x 数据。
        y (Tensor): 形状为 [num_samples, 12, 2] 的 y 数据。
    """
    data = []
    x_list = []
    y_list = []

    for _ in range(num_samples):
        x_seq = torch.zeros(8, 2)
        y_seq = torch.zeros(12, 2)

        # 计算夹角的弧度
        angle_radians = math.radians(angle_degrees)

        # 生成 x 路径
        for i in range(8):
            x_seq[i, 0] = i + 1
            x_seq[i] += torch.randn(2) * noise_std*(8-i)/2
            
        start = [0,0]
        for i in range(12):
            speed = 1
            y_seq[i, 0] = start[0] +1
            y_seq[i, 1] = math.tan(angle_radians) * 1+start[1]
            start = [y_seq[i, 0], y_seq[i, 1]]
            y_seq[i, 0] += torch.randn(1)[0] * noise_std*(i/10)
            y_seq[i, 1] += torch.randn(1)[0] * noise_std*(i/2)
            
            
        # 添加噪声到 x
        
        # x_seq += torch.randn(8, 2) * noise_std

        # y_seq += torch.randn(12, 2) * noise_std
        # 计算 y 路径
        # y_seq[0] = x_seq[-1] + torch.randn(2) * noise_std

        # for i in range(1, 12):
        #     y_seq[i] = y_seq[i - 1] + torch.randn(2) * noise_std

        x_seq = x_seq- x_seq[-1]
        data.append([x_seq.numpy(),y_seq.numpy()])


    return data

def gen_noise_dataset(num_samples, noise_std=0.1, angle_degrees=45):
    """
    生成玩具数据集，控制 y 的路径方向与 x 轴的夹角

    参数:
        num_samples (int): 要生成的样本数。
        noise_std (float): 噪声标准差。
        angle_degrees (float): y 路径与 x 轴的夹角（度数）。

    返回:
        x (Tensor): 形状为 [num_samples, 8, 2] 的 x 数据。
        y (Tensor): 形状为 [num_samples, 12, 2] 的 y 数据。
    """
    data = []
    x_list = []
    y_list = []

    for _ in range(num_samples):
        x_seq = torch.zeros(8, 2)
        y_seq = torch.zeros(12, 2)

        # 计算夹角的弧度
        angle_radians = math.radians(angle_degrees)

        # 生成 x 路径
        for i in range(8):
            x_seq[i, 0] = i + 1
            x_seq[i] += torch.randn(2) * noise_std*(8-i)/2
            
        start = [0,0]
        for i in range(12):
            
            y_seq[i,0] = 1
            y_seq[i] += torch.randn(2)* noise_std
            # y_seq[i, 0] = torch.randn(1)[0] * noise_std
            # y_seq[i, 1] = math.tan(angle_radians) * 1+start[1]
            # start = [y_seq[i, 0], y_seq[i, 1]]
            # y_seq[i, 0] += torch.randn(1)[0] * noise_std*(i/10)
            # y_seq[i, 1] += torch.randn(1)[0] * noise_std*(i/2)
            
            
        # 添加噪声到 x
        
        # x_seq += torch.randn(8, 2) * noise_std

        # y_seq += torch.randn(12, 2) * noise_std
        # 计算 y 路径
        # y_seq[0] = x_seq[-1] + torch.randn(2) * noise_std

        # for i in range(1, 12):
        #     y_seq[i] = y_seq[i - 1] + torch.randn(2) * noise_std

        x_seq = x_seq- x_seq[-1]
        data.append([x_seq.numpy(),y_seq.numpy()])


    return data

if __name__ =='__main__':
    num_samples = int(1e3)
    data1 = gen_toy_dataset(num_samples = num_samples, noise_std = 0.1, angle_degrees = 60)
    data2 = gen_toy_dataset(num_samples = num_samples, noise_std = 0.1, angle_degrees = -60)
    data3 = gen_toy_dataset(num_samples = num_samples, noise_std = 0.1, angle_degrees = 0)
    data_n = gen_noise_dataset(num_samples = 7*num_samples, noise_std = 0.3, angle_degrees = 0)
    data1.extend(data2)
    data1.extend(data3)
    data1.extend(data_n)
    
    # ipdb.set_trace()
    plt.figure()
    # for i in range(num_samples):
    for i,(x,y) in enumerate(data1):
        plt.plot(x[:,0],x[:,1], color = 'blue', marker='.', alpha=0.5)
        plt.plot(y[:,0],y[:,1], color = 'red', marker='.', alpha=0.5)
    plt.savefig('/data2/wuqi/project/zzz.png', dpi=300)
    plt.close()
    
    

    