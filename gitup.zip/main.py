import os, sys, time
import importlib
import torch
import numpy as np
from torch.utils.tensorboard import SummaryWriter

from model import RecurrentTransFormer as MODEL
from model import AgentModel
# from model import SoftModel as AgentModel

# from model import ModeModel as AgentModel
# from social_vae import SocialVAE
# from data_svae import Dataloader
import torch.nn as nn
from data import Dataloader
# from SocialVAE.utils import FPC, seed, get_rng_state, set_rng_state, vis

from util import ADE_FDE
import ipdb
import argparse
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE

parser = argparse.ArgumentParser()
parser.add_argument("--train", nargs='+', default=[''])
parser.add_argument("--test", nargs='+', default=[''])
parser.add_argument("--frameskip", type=int, default=1)
parser.add_argument("--config", type=str, default=None)
parser.add_argument("--ckpt", type=str, default=None)
parser.add_argument("--device", type=str, default='0')
parser.add_argument("--dataset", type=str, default='hotel')
parser.add_argument("--seed", type=int, default=1)
parser.add_argument("--no-fpc", action="store_true", default=False)
parser.add_argument("--fpc-finetune", action="store_true", default=False)
parser.add_argument("--retrain", type=bool, default=False)
parser.add_argument("--vis", type=bool, default=False)
parser.add_argument("--pixel", type=bool, default=False)
parser.add_argument("--edtion", type=str, default='0')
parser.add_argument("--data_dir", type=str, default='/')
parser.add_argument("--lr", type=float, default=0.001)
parser.add_argument("--lamb", type=float, default=0.1)
parser.add_argument("--inference", type=bool, default=False)


# python main.py --dataset sdd  --edtion topk --device 1  --lamb 0.04 --lr 0.0004 --retrain False --pixel True --data_dir /data1/wuqi/data/EMP/


def train(model,dataset,epoch,optimizer=None,static_modes=None, modality_labels=None):
    print('+++++ train +++++')
    # modality_labels = None
    model.train()
    e2e_model.eval()
    losses = {}
    ind_counts = torch.zeros(20)
    for batch_idx, item in enumerate(dataset):
        x,y,neighbor = item[0], item[1],item[2]
        
        model_out = model(agent=x,modality_labels=modality_labels,neighbor=neighbor)
        pred_traj = model_out[0]
        pred_prob = model_out[1]
        score = None
        
        loss, ind_count = model.get_loss(pred_traj,y,pred_prob=pred_prob,modality_labels=modality_labels,static_modes=static_modes)
        ind_counts += ind_count.detach().cpu()
        # if epoch >1:
        loss = model.get_prob_loss(loss, pred_traj, y, score,pred_prob,modality_labels=modality_labels)
        loss["total"].backward()
        optimizer.step()
        optimizer.zero_grad()
        for k, v in loss.items():
            if k not in losses: 
                losses[k] = v.item()
            else:
                losses[k] = (losses[k]*batch_idx+v.item())/(batch_idx+1)
        sys.stdout.write("\r" )
        sys.stdout.write("{}/{}| ".format(batch_idx+1, len(dataset)) )
        for k, v in losses.items():
            sys.stdout.write("{}: {:.3f}| ".format(k, v) )
        sys.stdout.flush()
    

    sys.stdout.write("\r" )
    sys.stdout.flush()
    
    # print() 
    # print(ind_counts)
    return losses, ind_counts

def test(model,e2e_model,dataset,epoch=-1,modality_labels=None):
    print('\n+++++ test  +++++')
    model.eval()
    e2e_model.eval()
    e2e_model = None
    ADE, FDE,BADE, BFDE = [], [], [], []
    batch = 0
    
    AGENT,GT,PRED,PROB = [], [], [], []
    
    time_cost = 0
    dataset_len = 0
    batch_count = 0
    with torch.no_grad():
        ind_counts = torch.zeros(20)
        for agent, gt, neighbor in dataset:
            batch_count+=1
            batch += agent.size(0)
            
            ### create moal labels
            # if e2e_model is not None:
            #     modality_labels = e2e_model(agent[...,:2])
            # else:
            #     print('+'*20)
            #     print('no modality labels!!!')
            #     modality_label = torch.randn_like(gt)
            #     modality_labels =modality_label[:,None,:,:].repeat(1,20,1,1)
            tic = time.perf_counter()
            model_out = model(agent=agent,modality_labels=modality_labels,neighbor=neighbor)
            toc = time.perf_counter()
            time_cost += toc-tic
            pred_traj = model_out[0]
            pred_prob = model_out[1] # B, 20
            
            ade, fde = ADE_FDE(pred_traj, gt) # B, pred_num
            
            distance = torch.norm(pred_traj - gt.unsqueeze(1), dim=-1).mean(dim=-1) # [batch_size pred_num pred_len]
            closest_indices = torch.min(distance, dim=-1)[1]
            ind_count = torch.bincount(closest_indices, minlength=20).detach().cpu()
            ind_counts += ind_count
            batch_ade, batch_fde = ade, fde
            ade = torch.min(ade, dim=1)[0]
            fde = torch.min(fde, dim=1)[0]
            
            ### append list
            ADE.append(ade)
            FDE.append(fde)
            BADE.append(batch_ade)
            BFDE.append(batch_fde)
            ### model outs
            AGENT.append(agent[...,:2])
            GT.append(gt)
            PRED.append(pred_traj)
            PROB.append(pred_prob)
        
        
            
            
        ADE = torch.cat(ADE)
        FDE = torch.cat(FDE)
        
        BADE = torch.cat(BADE,dim=0)
        BFDE = torch.cat(BFDE,dim=0)
        PROB = torch.cat(PROB,dim=0)
        # PROB = None
        # if False:
        
            
            
            
            
        ### rescale metrics
        if torch.is_tensor(config.WORLD_SCALE) or config.WORLD_SCALE != 1:
            if not torch.is_tensor(config.WORLD_SCALE):
                config.WORLD_SCALE = torch.as_tensor(config.WORLD_SCALE, device=ADE.device, dtype=ADE.dtype)
            
            ADE *= config.WORLD_SCALE
            FDE *= config.WORLD_SCALE
            
            BADE *= config.WORLD_SCALE[:,None]
            BFDE *= config.WORLD_SCALE[:,None]
            
        ### brief ADE/FDE
        BADE = BADE + (1-PROB)**2
        BFDE = BFDE + (1-PROB)**2
        BADE = torch.min(BADE, dim=1)[0]
        BFDE = torch.min(BFDE, dim=1)[0]
        
        ### eval in whole dataset
        ade = ADE.mean()
        fde = FDE.mean()
        bade = BADE.mean()
        bfde = BFDE.mean()
        toc = time.time()
        print("  ADE/  FDE:{:.2f}/{:.2f}\nB-ADE/B-FDE:{:.2f}/{:.2f}".format(ade, fde, bade, bfde))
        print("time:{:.5f}".format(100*(time_cost/batch)))
        
        if False:
        # if True:
        # if epoch >=13:
            AGENT = torch.cat(AGENT,dim=0)
            GT = torch.cat(GT,dim=0)
            
            PRED = torch.cat(PRED,dim=0)
            
            
            
            pastel={
                "blue": "#92C6FF",
                "green": "#97F0AA",
                "red": "#FF9F9A",
                "purple": "#D0BBFF",
                "yellow": "#FFFEA3",
                "cyan": "#B0E0E6",
                "brown": "#DEB887",
                "gold": "#FFD700",
                "navy": "#6495ED",
                "violet": "#DDA0DD"
            }
            # ipdb.set_trace()
            # print()
            # # plt.style.use('seaborn')
            # for k in range(20):
            #     save_path = 'fig/heads/'+settings.dataset+'_head'+str(k+1)+'.png'
            #     plt.figure(figsize=(8,6))
            #     # plt.scatter(AGENT[:,:,0].cpu().numpy(), AGENT[:,:,1].cpu().numpy(),color=pastel['green'],s=2)
            #     # plt.scatter(PRED[:,k,:,0].cpu().numpy(), PRED[:,k,:,1].cpu().numpy(),color=pastel['red'],s=2)
            #     plt.axhline(color='black', alpha=0.5)
            #     plt.axvline(color='black', alpha=0.5)
            #     plt.scatter(AGENT[:,:,0].cpu().numpy(), AGENT[:,:,1].cpu().numpy(),color='green',s=2,zorder=2)
            #     plt.scatter(PRED[:,k,:,0].cpu().numpy(), PRED[:,k,:,1].cpu().numpy(),color='red',s=2,zorder=2)
                
            #     plt.xlim(-8,16)
            #     plt.ylim(-8,8)
            #     plt.title('Predicted trajectories of predictor'+str(k+1), fontsize=12)
            #     plt.savefig(save_path,dpi=300,bbox_inches='tight')
            #     plt.close()
                    
            
            # vis(obs_trajs=AGENT, queries=None, gt_trajs=GT, y_tests =None,y_linear=None,y_kf =None, pred_trajs=PRED, global_fig=False, save_path=save_path,probs=None)

    return ade, fde, bade, bfde, ind_counts


if __name__ == "__main__":
    
    
    settings = parser.parse_args()
    settings.train[0] = settings.data_dir + settings.dataset +'/train'
    settings.test[0] = settings.data_dir + settings.dataset +'/test'
    if settings.dataset in ['rebound', 'score']:
        settings.train[0] = settings.data_dir+'/nba/' + settings.dataset +'/train'
        settings.test[0] = settings.data_dir+'/nba/' + settings.dataset +'/test'
    # settings.config =  'SocialVAE/config/' + settings.dataset + '.py'
    if settings.dataset in ['eth', 'hotel', 'univ', 'zara01', 'zara02']:
        settings.config =  'config.py'
    elif settings.dataset in ['rebound', 'score']:
        settings.config =  'config/' + 'nba_' +settings.dataset+ '.py'
    else:
        settings.config =  'config/' + 'sdd_pixel' + '.py'
        
    print()
    print(settings.config)
    print()
    edtion = settings.edtion
    settings.ckpt = 'ckpt/' + settings.dataset+'_' +settings.edtion+'_lr_' +str(settings.lr)+'_lamb_'+ str(settings.lamb)
    
    
    
    
    os.makedirs(settings.ckpt,exist_ok=True)
    
    spec = importlib.util.spec_from_file_location("config", settings.config)
    config = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(config)
    
    plot_on = settings.vis
    pixel = settings.pixel
    
    config.LEARNING_RATE = settings.lr
    
    
    ### device
    if settings.device is None:
        settings.device = "cuda" if torch.cuda.is_available() else "cpu"
    settings.device = "cuda:" + settings.device
    settings.device = torch.device(settings.device)
    torch.manual_seed(3407)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    torch.cuda.manual_seed(3407)
    
    ### 
    inclusive = [config.INCLUSIVE_GROUPS for _ in range(len(settings.test))]
    kwargs = dict(
            batch_first=True, frameskip=settings.frameskip,
            ob_horizon=config.OB_HORIZON, pred_horizon=config.PRED_HORIZON,
            device=settings.device, seed=settings.seed)
    test_data, train_data = None, None
    
    test_dataset = Dataloader(
            settings.test, **kwargs, inclusive_groups=inclusive,
            batch_size=config.BATCH_SIZE, shuffle=False
    )
    test_data = torch.utils.data.DataLoader(test_dataset, 
        collate_fn=test_dataset.collate_fn,
        batch_sampler=test_dataset.batch_sampler
    )
    ### clustering
    all_test = test_dataset.data
    gt_ls = []
    for i ,item in enumerate(test_data):
        gt_ls.append(item[1])
    # Y = np.stack(gt_ls, axis=0)
    Y = torch.cat(gt_ls, dim=0).cpu().numpy()
    from sklearn.cluster import KMeans
    reshaped_Y = Y[:,-1,:2].squeeze()

    # 指定聚类的簇数（可以根据您的需求进行调整）
    n_clusters = 20

    # 创建 K-means 模型
    kmeans = KMeans(n_clusters=n_clusters)

    # 拟合模型并进行聚类
    kmeans.fit(reshaped_Y)

    # 获取聚类中心
    cluster_centers = kmeans.cluster_centers_

    # 获取每个数据点的标签（指示它属于哪个簇）
    labels = kmeans.labels_
    label_count = [0 for _ in range(n_clusters)]
    label_avg = labels.shape[0]/n_clusters
    for i in range(n_clusters):
        label_count[i] = np.count_nonzero(labels == i)
    high_modes = [i for i, value in enumerate(label_count) if value > label_avg]
    low_modes = [i for i, value in enumerate(label_count) if value <= label_avg]
    static_modes = [high_modes, low_modes]
    
    fut_centers = [[] for _ in range(n_clusters)]
    for j in range(n_clusters):
        fut_centers[j] = Y[labels==j].mean(axis=0)
    fut_centers = np.stack(fut_centers, axis=0)
    # fut_centers = torch.cat(fut_centers,dim=0)
   
    colors = [
    'red', 'green', 'blue', 'yellow', 'orange',
    'purple', 'pink', 'cyan', 'magenta', 'brown',
    'violet', 'teal', 'lime', 'indigo', 'maroon',
    'olive', 'navy', 'grey', 'black', 'white'
    ]

    if not settings.inference :
        train_dataset = Dataloader(
                settings.train, **kwargs, inclusive_groups=inclusive, 
                flip=True, rotate=True, scale=True,
                batch_size=config.BATCH_SIZE, shuffle=True, batches_per_epoch=config.EPOCH_BATCHES
        )
        train_data = torch.utils.data.DataLoader(train_dataset,
        collate_fn=train_dataset.collate_fn,
        batch_sampler=train_dataset.batch_sampler
    )
        batches = train_dataset.batches_per_epoch

    model = AgentModel(
        in_size=2, 
        # config=config,
        obs_len=config.OB_HORIZON, 
        pred_len=config.PRED_HORIZON, 
        embed_size=256, 
        num_spa_int_layer=1, 
        heads=4, 
        forward_expansion=2,
        lamb = settings.lamb
        )
    model.to(settings.device)
    
    optimizer = torch.optim.Adam(model.parameters(), lr=config.LEARNING_RATE)
    start_epoch = 0
    
    if settings.ckpt:
        ckpt = os.path.join(settings.ckpt, "ckpt-last")
        ckpt_best = os.path.join(settings.ckpt, "ckpt-best")
        if settings.retrain:
            if os.path.isfile(ckpt):
                os.unlink(ckpt)
            if os.path.isfile(ckpt_best):
                os.unlink(ckpt_best)
        if os.path.exists(ckpt_best):
            
            state_dict = torch.load(ckpt_best, map_location=settings.device)
            ade_best = state_dict["ade"]
            fde_best = state_dict["fde"]
            b_ade_best = state_dict["bade"]
            b_fde_best = state_dict["bfde"]
            best_ep = state_dict["epoch"]
        else:
            ade_best = 1e5
            fde_best = 1e5
            b_ade_best = 1e5
            b_fde_best = 1e5

        if settings.inference : 
            ckpt = ckpt_best
        if os.path.exists(ckpt):
            print("Load from ckpt:", ckpt)
            state_dict = torch.load(ckpt, map_location=settings.device)
            model.load_state_dict(state_dict["model"])
            if "optimizer" in state_dict:
                optimizer.load_state_dict(state_dict["optimizer"])
                
            start_epoch = state_dict["epoch"]
        end_epoch = start_epoch+1 if train_data is None or start_epoch >= config.EPOCHS else config.EPOCHS
    
    ### load end to end model
    e2e_model = AgentModel(
        in_size=2, 
        obs_len=config.OB_HORIZON, 
        pred_len=config.PRED_HORIZON, 
        embed_size=256, 
        num_spa_int_layer=1, 
        heads=4, 
        forward_expansion=2
        )
    e2e_model.to(settings.device)
    # ee_ckpt = os.path.join('/data1/wuqi/project/ckpt/'+settings.dataset+'_0', "ckpt-best")
    # ee_state_dict = torch.load(ee_ckpt, map_location=settings.device)
    # e2e_model.load_state_dict(ee_state_dict["model"])
    e2e_model.eval()
    
    ade, fde, bade, bfde = 1e3, 1e3, 1e3, 1e3
    
    ### load params in model 
    # PARAM = []
    # for name, param in model.named_parameters():
    #     if 'outs' in name and 'weight' in name:
    #         PARAM.append(param)
    
    # for idx, param in enumerate(PARAM):
    #     batchsize = param.size(1)
    #     param = param.t().detach().cpu().numpy()
        
    #     param = param.reshape(int(batchsize/4),-1)
    #     plt.imshow(param, cmap='viridis')
    #     plt.colorbar()  
    #     plt.xticks([])
    #     plt.yticks([])
    #     plt.savefig('/data1/wuqi/project/fig/reghead'+str(idx)+'.png',dpi=300,bbox_inches='tight')
    #     plt.close()
    
    ### 
    
    
    cluster_centers = torch.from_numpy(fut_centers).to(settings.device)
    
    # ade, fde, bade, bfde = test(model,e2e_model=e2e_model, dataset= test_data,modality_labels=cluster_centers)
    
    for epoch in range(start_epoch+1, end_epoch+1):
        if settings.inference : break
        if epoch <= config.EPOCHS:
            print('='*40)
            tic = time.time()
            losses, train_count = train(model=model,dataset=train_data,static_modes=static_modes, epoch=epoch, optimizer =optimizer,modality_labels=cluster_centers)
            toc = time.time()
            
            sys.stdout.write("Epoch {}/{} t cost:{:.2f}|".format(epoch, config.EPOCHS,toc-tic))
            for k, v in losses.items():
                sys.stdout.write("{}: {:.3f}| ".format(k, v) )
            sys.stdout.flush()
        if epoch >= config.TEST_SINCE:
            ade, fde, bade, bfde, test_count = test(model,e2e_model=e2e_model, dataset= test_data,modality_labels=cluster_centers,epoch=epoch)
            # exit()
        state = dict(
            model=model.state_dict(),
            optimizer=optimizer.state_dict(),
            ade=ade, fde=fde, bade=bade,bfde=bfde,
            epoch=epoch
        )
        
        torch.save(state, ckpt)

        
        if bade < b_ade_best:
            b_ade_best = bade
            b_fde_best = bfde
            
        # if True:  
        if ade+fde < ade_best+fde_best:
            # 将张量转换为NumPy数组
            train_count = train_count.numpy()
            # 绘制直方图
            # x_labels = list(range(1, 21))

            # # 绘制直方图
            # # plt.style.use('seaborn')
            # plt.figure(figsize=(8,6))
            # plt.bar(x_labels, train_count, align='center', alpha=0.7, color='b', edgecolor='k')
            # plt.xticks(range(1,21))
            # plt.title('Predictor selection frequency on the '+settings.dataset+' training set', fontsize=12)
            # plt.savefig('bins/'+settings.dataset+'_train_bins.png',dpi=300,bbox_inches='tight')
            # plt.close()
            # test_count = test_count.numpy()

            # # 绘制直方图
            # plt.figure(figsize=(8,6))
            # plt.bar(x_labels, test_count, align='center', alpha=0.7, color='b', edgecolor='k')
            # plt.xticks(range(1,21))
            # plt.title('Predictor selection frequency on the '+settings.dataset+' testing set', fontsize=12)
            # plt.savefig('bins/'+settings.dataset+'_test_bins.png',dpi=300,bbox_inches='tight')
            # plt.close()
            ade_best = ade
            fde_best = fde
            best_ep = epoch
            state_best = dict(
                model=state["model"],
                ade=ade, fde=fde, bade=bade,bfde=bfde,
                epoch=epoch
            )
            torch.save(state_best, ckpt_best)
            print('epoch{} best  ade/ fde:{:.3f}/{:.3f}'.format(epoch,ade_best, fde_best))
            print('epoch{} best bade/bfde:{:.3f}/{:.3f}'.format(epoch,b_ade_best, b_fde_best))
    
    state_dict = torch.load(ckpt_best, map_location=settings.device)
    model.load_state_dict(state_dict["model"])
    ade, fde, bade, bfde, ind_counts = test(model,e2e_model=e2e_model, dataset= test_data,modality_labels=cluster_centers)
    ### write into log
    file_path = "eval.txt"
    text_to_append = "{} ed: {} lr:{} lambda:{} \nbest ep {} best ADE/FDE: {:.2f}/{:.2f}|||best BADE/BFDE: {:.2f}/{:.2f}".format(settings.dataset,settings.edtion, config.LEARNING_RATE, settings.lamb, best_ep,ade_best,fde_best,b_ade_best, b_fde_best)
    text_to_append =  text_to_append+'\n'
    
    ### 
    def append_to_file(file_path, text):
        with open(file_path, 'a') as file:
            file.write(text + '\n')
    append_to_file(file_path, text_to_append)
        
    