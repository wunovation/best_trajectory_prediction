import torch
import torch.nn as nn
import math
from torch.nn import functional as F
from .block_utils import MLP, attention,LayerNorm, FeedForwardLayer
import ipdb
class MultihHeadAttention(nn.Module):
    def __init__(self, d_model, h, dropout=0.1, islinear=True):
        super(MultihHeadAttention, self).__init__()

        assert d_model % h == 0

        self.d_k = d_model // h
        self.h = h

        self.w_key = MLP(in_dim=d_model,d_model = d_model, out_dim=d_model, islinear = islinear)
        self.w_query = MLP(in_dim=d_model,d_model = d_model, out_dim=d_model, islinear = islinear)
        self.w_value = nn.Linear(d_model, d_model)
        self.fc_out = nn.Linear(d_model, d_model)

        self.dropout = nn.Dropout(dropout)

        self.atten = None  # 返回的attention张量，现在还没有，保存给可视化使用

    def forward(self, query, key, value, mask=None):
        if mask is not None:
            mask = mask.unsqueeze(1)  # head导致query等多了一维
        batch_size, seq_len, C = query.shape

        query_emb = self.w_query(query)
        key_emb = self.w_key(key)
        value_emb = self.w_value(value)
        
        query = query_emb.view(batch_size, -1, self.h, self.d_k).transpose(1, 2)
        key = key_emb.view(batch_size, -1, self.h, self.d_k).transpose(1, 2)
        value = value_emb.view(batch_size, -1, self.h, self.d_k).transpose(1, 2)

        x, self.atten = attention(query, key, value, mask, self.dropout)
        self.atten, context  = attention(query, key, value, mask, self.dropout)
        x = context.transpose(1, 2).contiguous().view(batch_size, -1, self.h * self.d_k)

        x = self.fc_out(x)


        return x
    
class TransformerEncBlock(nn.Module):
    def __init__(self, embed_size, head, forward_expansion, dropout, islinear=True):
        super(TransformerEncBlock, self).__init__()

        self.attn = MultihHeadAttention(embed_size, head, islinear=islinear)
        self.norm1 = nn.Sequential()
        self.norm2 = nn.Sequential()
        self.feed_forward = FeedForwardLayer(embed_size, forward_expansion)
        self.dropout = nn.Dropout(dropout)

    def forward(self, query, key, value, mask):
        logits = self.attn(query, key, value, mask)
        x = self.dropout(self.norm1(logits + query))
        forward = self.feed_forward(x)
        out = self.dropout(self.norm2(forward + x))
        return out
    
class RTREncBlock(nn.Module):
    def __init__(self, embed_size, head, forward_expansion, dropout, islinear=True):
        super(RTREncBlock, self).__init__()

        # self.norm1 = nn.Sequential()
        # self.norm2 = nn.Sequential()
        self.norm1 = LayerNorm(embed_size)
        self.norm2 = LayerNorm(embed_size)
        self.feed_forward = FeedForwardLayer(embed_size, forward_expansion)
        self.dropout = nn.Dropout(dropout)
        self.L1, self.L2 = 0, 0
        self.batch_size = 0
        
        self.ob_radius = 2
        hidden_dim_fx = embed_size
        hidden_dim_fy = embed_size
        self.embed_dim = embed_size
        hidden_dim_by = 256
        feature_dim = 256
        neighbor_embed_dim = 128
        z_dim = 32
        d_dim = 2
        
        self.embed_s = torch.nn.Sequential(
            torch.nn.Linear(4, 64),             # v, a
            torch.nn.ReLU6(),
            torch.nn.Linear(64, self.embed_dim),
        )
        self.embed_n = torch.nn.Sequential(
            torch.nn.Linear(4, 64),             # dp, dv
            torch.nn.ReLU6(),
            torch.nn.Linear(64, neighbor_embed_dim),
            torch.nn.ReLU6(),
            torch.nn.Linear(neighbor_embed_dim, neighbor_embed_dim)
        )
        self.embed_k = torch.nn.Sequential(
            torch.nn.Linear(3, feature_dim),    # dist, bear angle, mpd
            torch.nn.ReLU6(),
            torch.nn.Linear(feature_dim, feature_dim),
            torch.nn.ReLU6(),
            torch.nn.Linear(feature_dim, feature_dim)
        )
        self.embed_q = torch.nn.Sequential(
            torch.nn.Linear(hidden_dim_fx, feature_dim),
            torch.nn.ReLU6(),
            torch.nn.Linear(feature_dim, feature_dim),
            torch.nn.ReLU6(),
            torch.nn.Linear(feature_dim, feature_dim)
        )
        self.attention_nonlinearity = torch.nn.LeakyReLU(0.2)

        self.rnn_fx = torch.nn.GRU(self.embed_dim+neighbor_embed_dim, hidden_dim_fx)
        self.rnn_fx_init = torch.nn.Sequential(
            torch.nn.Linear(2, hidden_dim_fx), # dp
            torch.nn.ReLU6(),
            torch.nn.Linear(hidden_dim_fx, hidden_dim_fx*self.rnn_fx.num_layers),
            torch.nn.ReLU6(),
            torch.nn.Linear(hidden_dim_fx*self.rnn_fx.num_layers, hidden_dim_fx*self.rnn_fx.num_layers),
        )
        self.rnn_by = torch.nn.GRU(self.embed_dim+neighbor_embed_dim, hidden_dim_by)

        
        self.rnn_fy = torch.nn.GRU(z_dim, hidden_dim_fy)
        self.rnn_fy_init = torch.nn.Sequential(
            torch.nn.Linear(hidden_dim_fx, hidden_dim_fy*self.rnn_fy.num_layers),
            torch.nn.ReLU6(),
            torch.nn.Linear(hidden_dim_fy*self.rnn_fy.num_layers, hidden_dim_fy*self.rnn_fy.num_layers)
        )

    def motion_embedding(self, agent, neighbor, modality_label=None):
        # x: (L1+1) x N x 6
        # y: L2 x N x 2
        # neighbor: (L1+L2+1) x N x Nn x 6
        with torch.no_grad():
            # agent=agent.permute(1,0,2)
            
            # neighbor=neighbor.permute(1,0,2,3)
            
            self.L1 = agent.size(1)-1
            self.batch_size = neighbor.size(0)
            neighbor_num = neighbor.size(2)
            state = agent

            x = state[...,:2]                       
            self.L2 = 0
                
            
            v = x[:,1:] - x[:,:-1]                      
            accelerate = v[:,1:] - v[:,:-1]                      
            
            accelerate = torch.cat((state[:,1:2,4:6], accelerate),dim=1)  # B 7 2
            neighbor_x = neighbor[...,:2]           # (L+1) x N x Nn x 2
            neighbor_v = neighbor[:,1:,:,2:4]       # L x N x Nn x 2
            
            dp = neighbor_x - x.unsqueeze(-2)       # (L+1) x N x Nn x 2
            dv = neighbor_v - v.unsqueeze(-2)       # L x N x Nn x 2

            # social features
            dist = dp.norm(dim=-1)                          # (L+1) x N x Nn
            mask = dist <= self.ob_radius
            
            dp0, dp = dp[:,0], dp[:,1:]
            # mask0, mask = mask[:,0], mask[:,1:]
            dist = dist[:,1:]
            
            dot_dp_v = (dp @ v.unsqueeze(-1)).squeeze(-1)   # L x N x Nn
            bearing = dot_dp_v / (dist*v.norm(dim=-1).unsqueeze(-1)) # L x N x Nn
            bearing = bearing.nan_to_num(0, 0, 0)
            dot_dp_dv = (dp.unsqueeze(-2) @ dv.unsqueeze(-1)).view(self.batch_size,dp.size(1),neighbor_num)
            tau = -dot_dp_dv / dv.norm(dim=-1)              # L x N x Nn
            tau = tau.nan_to_num(0, 0, 0).clip(0, 7)
            mpd = (dp + tau.unsqueeze(-1)*dv).norm(dim=-1)  # L x N x Nn
            features = torch.stack((dist, bearing, mpd), -1)# L x N x Nn x 3
        mask0, mask = mask[:,0], mask[:,1:]
        
        key = self.embed_k(features)  #[7 512 50 3]                        # L x N x Nn x d
        motion_vec = self.embed_s(torch.cat((v, accelerate), -1)) #[512 512]
        n = self.embed_n(torch.cat((dp, dv), -1))  # ([7, 512, 50, 128])         # L x N x Nn x ...
        
        h = self.rnn_fx_init(dp0)                           # N x Nn x d
        h = (mask0.unsqueeze(-1) * h).sum(-2)               # N x d
        h = h.view(self.batch_size, -1, self.rnn_fx.num_layers)
        h = h.permute(2, 0, 1).contiguous()
        
        query_ls = []
        for t in range(self.L1):
            q_z = self.embed_q(h[-1])                         # N x d
            query_ls.append(q_z)
            
            '''
            q_z: B emb_size
            key: [512, 7, 50, 256] '[dist, bearing, mpd] embedding
            value: [512, 7, 50, 128] dp,dv embedding
            '''
            score, x_t = attention(query=q_z,key=key[:,t],value=n[:,t], mask=mask[:,t])
            # att = attention(q_z, key[:,t], mask[:,t])          # N x Nn
            # x_t = att.unsqueeze(-2) @ n[:,t]                  # N x 1 x d
            x_t = x_t.squeeze(-2)                           # N x d
            x_t = torch.cat((x_t, motion_vec[:,t]), -1).unsqueeze(0)
            _, h = self.rnn_fx(x_t, h)
        x = h[-1]
        
        return x,query_ls
    
    def modality_embedding(self, agent, neighbor, modality_labels=None):
        # x: (L1+1) x N x 6
        # modality_label:  B,modality_num  xpred_len x 2
        # neighbor: (L1+L2+1) x N x Nn x 6
        
        modality_num = modality_labels.size(1)
        inv_rnn_outs = []
        agent=agent.permute(1,0,2)
        neighbor=neighbor.permute(1,0,2,3)
        for m in range(modality_num):
            modality_label = modality_labels[:,m]
            with torch.no_grad():
                
                self.L1 = agent.size(1)-1
                self.batch_size = neighbor.size(0)
                neighbor_num = neighbor.size(2)
                state = agent

                x = state[...,:2]                       
                if modality_label is not None:
                    self.L2 = modality_label.size(1)
                    
                    x = torch.cat((x, modality_label), dim=1)    
                        
                else:
                    self.L2 = 0
                
                v = x[:,1:] - x[:,:-1]                      
                accelerate = v[:,1:] - v[:,:-1]                      
                
                accelerate = torch.cat((state[:,1:2,4:6], accelerate),dim=1)  # B 7 2
                neighbor_x = neighbor[...,:2]           # (L+1) x N x Nn x 2
                neighbor_v = neighbor[:,1:,:,2:4]       # L x N x Nn x 2
                
                dp = neighbor_x - x.unsqueeze(-2)       # (L+1) x N x Nn x 2
                dv = neighbor_v - v.unsqueeze(-2)       # L x N x Nn x 2

                # social features
                dist = dp.norm(dim=-1)                          # (L+1) x N x Nn
                mask = dist <= self.ob_radius
                
                dp0, dp = dp[:,0], dp[:,1:]
                # mask0, mask = mask[:,0], mask[:,1:]
                dist = dist[:,1:]
                
                dot_dp_v = (dp @ v.unsqueeze(-1)).squeeze(-1)   # L x N x Nn
                bearing = dot_dp_v / (dist*v.norm(dim=-1).unsqueeze(-1)) # L x N x Nn
                bearing = bearing.nan_to_num(0, 0, 0)
                dot_dp_dv = (dp.unsqueeze(-2) @ dv.unsqueeze(-1)).view(self.batch_size,dp.size(1),neighbor_num)
                tau = -dot_dp_dv / dv.norm(dim=-1)              # L x N x Nn
                tau = tau.nan_to_num(0, 0, 0).clip(0, 7)
                mpd = (dp + tau.unsqueeze(-1)*dv).norm(dim=-1)  # L x N x Nn
                features = torch.stack((dist, bearing, mpd), -1)# L x N x Nn x 3
            mask0, mask = mask[:,0], mask[:,1:]
            
            key = self.embed_k(features)  #[7 512 50 3]                        # L x N x Nn x d
            motion_vec = self.embed_s(torch.cat((v, accelerate), -1)) #[512 512]
            neighbor_motion = self.embed_n(torch.cat((dp, dv), -1))  # ([7, 512, 50, 128])         # L x N x Nn x ...
            
            h = self.rnn_fx_init(dp0)                           # N x Nn x d
            h = (mask0.unsqueeze(-1) * h).sum(-2)               # N x d
            h = h.view(self.batch_size, -1, self.rnn_fx.num_layers)
            h = h.permute(2, 0, 1).contiguous()
            
            
            for t in range(self.L1):
                q_z = self.embed_q(h[-1])                         # N x d
                
                score, x_t = attention(query=q_z,key=key[:,t],value=neighbor_motion[:,t], mask=mask[:,t])
                # att = attention(q_z, key[:,t], mask[:,t])          # N x Nn
                # x_t = att.unsqueeze(-2) @ n[:,t]                  # N x 1 x d
                x_t = x_t.squeeze(-2)                           # N x d
                x_t = torch.cat((x_t, motion_vec[:,t]), -1).unsqueeze(0)
                _, h = self.rnn_fx(x_t, h)
            
            x = h[-1]
            mask_t = mask[:,self.L1:self.L1+self.L2].unsqueeze(-1)               # L2 x N x Nn x 1
            n_t = neighbor_motion[:,self.L1:self.L1+self.L2]                                   # L2 x N x Nn x d
            n_t = (mask_t * n_t).sum(-2)                        # L2 x N x d
            motion_vec_t = motion_vec[:,self.L1:self.L2+self.L2]
           
            x_t = torch.cat((n_t, motion_vec_t), dim=2)
            x_t = torch.flip(x_t, (0,))
            b, _ = self.rnn_by(x_t)                             # L2 x N x n_layer*d
            if self.rnn_by.num_layers > 1:
                b = b[...,-b.size(-1)//self.rnn_by.num_layers:]
            b = torch.flip(b, (0,))
            inv_rnn_outs.append(b.unsqueeze(0))
        inv_rnn_outs = torch.cat(inv_rnn_outs,dim=0)
    
        return inv_rnn_outs
    
    def forward(self, agent, neighbor, y=None):
        
        logits,query_ls = self.motion_embedding(agent, neighbor)
        
        # x = self.dropout(self.norm1(logits + query))
        x = self.dropout(self.norm1(logits))
        forward = self.feed_forward(x)
        out = self.dropout(self.norm2(forward + x))
        return out
    
class RTR_Encoder(nn.Module):
    def __init__(
        self,
        embed_size,
        heads,
        forward_expansion,
        num_layers=1,
        dropout=0.1,
        islinear=True
    ):
        super(RTR_Encoder, self).__init__()
        num_layers = 1
        self.layers = nn.ModuleList(
            [
                RTREncBlock(embed_size, heads, forward_expansion, dropout, islinear=islinear)
                for _ in range(num_layers)
            ]
        )
        self.dropout = nn.Dropout(dropout)

    def forward(self, x, neighbor):
        for layer in self.layers:
            x = layer(x, neighbor)
        memoryout = x
        return memoryout
    
    