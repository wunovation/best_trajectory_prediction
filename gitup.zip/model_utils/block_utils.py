import torch
import torch.nn as nn
import math
from torch.nn import functional as F
import ipdb

class LabelSmoothCrossEntropyLoss(nn.Module):
    def __init__(self, smoothing=0.1, num_classes=10):
        super(LabelSmoothCrossEntropyLoss, self).__init__()
        self.smoothing = smoothing
        self.num_classes = num_classes

    def forward(self, inputs, targets):
        log_prob = torch.nn.functional.log_softmax(inputs, dim=-1)
        batch_size = targets.size(0)
        targets = torch.zeros_like(log_prob).scatter_(1, targets.view(-1, 1), 1)
        targets = (1 - self.smoothing) * targets + self.smoothing / self.num_classes
        loss = (-targets * log_prob).sum(dim=-1).mean()
        return loss
    
class MultiHeadRegression(nn.Module):
    def __init__(self, embed_size=128, heads=20):
        super(MultiHeadRegression, self).__init__()
        d_dim =2 
        self.pred_len = 12
        self.pred_num = heads
        
        self.prob_head = torch.nn.Sequential(
            torch.nn.Linear(embed_size, embed_size*2),            
            torch.nn.ReLU6(),
            torch.nn.Linear(embed_size*2, self.pred_num),
            nn.Softmax(dim=-1)
        ) 
        # self.reg_head_in = torch.nn.Sequential(
        #     torch.nn.Linear(self.embed_dim, self.embed_dim*2),            
        #     torch.nn.ReLU6(),
        #     torch.nn.Linear(self.embed_dim*2, self.pred_len*self.pred_num*d_dim)
        # )
        self.reg_head_outs = nn.ModuleList([torch.nn.Linear(self.embed_dim*2, self.pred_len*2) for _ in range(self.pred_num)])
        
        
        
        
        
    def forward(self, inputs, targets):
        
        return inputs
        


class MLP(nn.Module):
    def __init__(self,in_dim,d_model,out_dim,islinear=False):
        super(MLP, self).__init__()
        if islinear:
            self.mlp = nn.Linear(d_model, d_model)  
        else :
            self.mlp = nn.Sequential(
                nn.Linear(d_model, d_model), 
                nn.ReLU6(), 
                nn.Linear(d_model, d_model)
                )
            
    def forward(self, x):
        x = self.mlp(x)
        
        return x
    
def attention(query,key,value, mask=None, dropout=None):
    # q: Bx emb
    # k: B x Nnum x emb
    # mask: B x Nnum
    attention_nonlinearity = torch.nn.LeakyReLU(0.2)
    
    score = (key @ query.unsqueeze(-1)).squeeze(-1)           # N x Nn
    score = attention_nonlinearity(score)              # N x Nn
    if mask is not None:
        score[~mask] = -float("inf")
    score = torch.nn.functional.softmax(score, dim=-1).nan_to_num()    # N x Nn
    
    if dropout is not None:
        score = dropout(score)
        
    logits = score.unsqueeze(-2) @ value
    return score, logits

class LayerNorm(nn.Module):
    def __init__(self, embedding_dim, eps=1e-6):
        super(LayerNorm, self).__init__()
        self.a = nn.Parameter(torch.ones(embedding_dim))
        self.b = nn.Parameter(torch.zeros(embedding_dim))
        self.eps = eps

    def forward(self, x):
        mean = x.mean(-1, keepdim=True)
        std = x.std(-1, keepdim=True)
        return self.a * (x-mean) / (std+self.eps) + self.b
    
class FeedForwardLayer(nn.Module):
    def __init__(self, d_model, forward_expansion):
        super(FeedForwardLayer, self).__init__()
        self.w1 = nn.Linear(d_model, d_model*forward_expansion)
        self.w2 = nn.Linear(d_model*forward_expansion, d_model)

    def forward(self, x):
        x_feat = self.w2((F.relu(self.w1(x))))
        return x_feat