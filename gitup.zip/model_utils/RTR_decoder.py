import torch
import torch.nn as nn
import math
from torch.nn import functional as F
from .block_utils import MLP, attention,LayerNorm, FeedForwardLayer
import ipdb

class RTRDecBlock(nn.Module):
    def __init__(self, embed_size, head, forward_expansion, dropout, islinear=True):
        super(RTRDecBlock, self).__init__()

        
        self.norm1 = LayerNorm(embed_size)
        self.norm2 = LayerNorm(embed_size)
        self.feed_forward = FeedForwardLayer(embed_size, forward_expansion)
        self.dropout = nn.Dropout(dropout)

    def forward(self, query, key, value, mask):
            
        score, logits = attention(query,key,value, dropout=None,mask = mask) 

        # x = self.dropout(self.norm1(logits + query))
        x = self.dropout(self.norm1(logits))
        forward = self.feed_forward(x)
        out = self.dropout(self.norm2(forward + x))
        return out, score

class RTR_Decoder(nn.Module):
    def __init__(
        self,
        embed_size,
        num_layers,
        heads,
        forward_expansion,
        dropout=0.1,
        islinear=False
    ):
        super(RTR_Decoder, self).__init__()

        self.layers = nn.ModuleList(
            [
                RTRDecBlock(embed_size, heads, forward_expansion, dropout, islinear=islinear)
                for _ in range(num_layers)
            ]
        )
        self.dropout = nn.Dropout(dropout)

    def forward(self, query, key, mask=None):
        
        for layer in self.layers:
            x, score = layer(query=query, key=key, value=key, mask=mask)

        return x, score