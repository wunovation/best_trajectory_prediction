<!-- example -->

python main.py --dataset sdd  --edtion topk --device 1  --lamb 0.04 --lr 0.0004 --retrain False --pixel True --data_dir /data1/wuqi/data/EMP/


--data_dir :<data dir of the training set>
the data structure should be as follows:
- data_dir
  - eth
  - univ
  - hotel
  - zara01
  - zara02
  - nba
    - rebound
    - score
--pixel True for sdd_pixel False for others
--retrain False to use ckpt; True to train from scratch
--lamb hyper parameter to balance weights
--lr learning rate
--edtion label for trails
--dataset ['eth', 'hotel','univ','zara01','zara02','sdd','rebound','score']


论文里的model 就是 AgentModel 其他model用来做消融实验，不用管